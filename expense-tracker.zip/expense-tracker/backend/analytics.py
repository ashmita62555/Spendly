"""Pandas analysis. Every function takes a DataFrame built by to_df() and returns plain JSON-safe data."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd


COLUMNS = ["id", "date", "category", "amount", "description"]
SORTS = {
    "date-desc": (["date", "id"], [False, False]),
    "date-asc": (["date", "id"], [True, True]),
    "amt-desc": (["amount", "id"], [False, False]),
    "amt-asc": (["amount", "id"], [True, True]),
    "az": (["_d", "id"], [True, True]),
    "za": (["_d", "id"], [False, False]),
    "cat": (["category", "date", "id"], [True, False, False]),
}
RANGES = {"all", "today", "week", "month", "custom"}
MONTH_RE = re.compile(r"(19|20)\d{2}-(0[1-9]|1[0-2])")


# ---------- helpers ----------
def _num(x):
    x = round(float(x), 2)
    return int(x) if x.is_integer() else x


def pct(new, old):
    return round((new - old) / old * 100, 1) if old else None


def _group(n, indian):
    s = str(n)
    if indian and len(s) > 3:  # 1234567 -> 12,34,567
        head, tail, parts = s[:-3], s[-3:], []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        return ",".join(parts + [tail])
    return f"{n:,}"


def money_text(n, cur):
    """Format an amount for text and charts using the chosen currency, e.g. ₹12,34,567 or $1,234,567."""
    n = int(round(n))
    return ("-" if n < 0 else "") + cur["symbol"] + _group(abs(n), cur["code"] == "INR")


def to_df(expenses) -> pd.DataFrame:
    df = pd.DataFrame(expenses, columns=COLUMNS)
    df["date"] = pd.to_datetime(df["date"], format="%Y-%m-%d")
    df["amount"] = pd.to_numeric(df["amount"]).astype(float)
    df["month"] = df["date"].dt.strftime("%Y-%m")
    return df


def records(df) -> list:
    return [
        {"id": int(r.id), "date": r.date.strftime("%Y-%m-%d"), "category": r.category, "amount": _num(r.amount), "description": r.description}
        for r in df.itertuples(index=False)
    ]


def month_label(key, fmt="%B %Y"):
    return pd.Timestamp(key + "-01").strftime(fmt)


# ---------- filtering & sorting ----------
def apply_filters(df, f, today):
    t = pd.Timestamp(today)
    m = pd.Series(True, index=df.index)
    if f.get("category"):
        m &= df["category"] == f["category"]
    rng = f.get("range", "all")
    if rng == "today":
        m &= df["date"] == t
    elif rng == "week":
        m &= df["date"] >= t - pd.Timedelta(days=t.weekday())
    elif rng == "month":
        m &= df["month"] == t.strftime("%Y-%m")
    elif rng == "custom":
        if f.get("from"):
            m &= df["date"] >= pd.Timestamp(f["from"])
        if f.get("to"):
            m &= df["date"] <= pd.Timestamp(f["to"])
    if f.get("min") is not None:
        m &= df["amount"] >= f["min"]
    if f.get("max") is not None:
        m &= df["amount"] <= f["max"]
    q = (f.get("q") or "").strip().lower()
    if q and len(df):
        hay = (
            df["description"] + " " + df["category"] + " "
            + df["date"].dt.strftime("%Y-%m-%d") + " " + df["date"].dt.strftime("%d %b %Y") + " "
            + df["amount"].map(lambda v: f"{v:.2f}".rstrip("0").rstrip("."))
        ).str.lower()
        m &= hay.str.contains(q, regex=False)
    out = df[m]
    by, asc = SORTS[f.get("sort", "date-desc")]
    out = out.assign(_d=out["description"].str.lower()).sort_values(by, ascending=asc, kind="mergesort")
    return out.drop(columns="_d")


# ---------- aggregates ----------
def categories(df, names, month=None):
    d = df[df["month"] == month] if month else df
    g = d.groupby("category")["amount"].agg(total="sum", n="count").reindex(names, fill_value=0)
    total = float(g["total"].sum())
    rows = []
    for cat, r in g.iterrows():
        n = int(r["n"])
        rows.append({
            "category": cat, "total": _num(r["total"]), "count": n,
            "average": round(float(r["total"]) / n, 2) if n else 0,
            "share": round(float(r["total"]) / total * 100, 1) if total else 0,
        })
    rows.sort(key=lambda r: (-r["total"], names.index(r["category"])))
    return {"total": _num(total), "categories": rows}


def _month_keys(today, n):
    t = pd.Timestamp(today).replace(day=1)
    return [(t - pd.DateOffset(months=i)).strftime("%Y-%m") for i in range(n - 1, -1, -1)]


def monthly(df, n, today):
    g = df.groupby("month")["amount"].agg(total="sum", n="count")
    rows = []
    for key in _month_keys(today, n):
        tot, cnt = (g.loc[key, "total"], int(g.loc[key, "n"])) if key in g.index else (0, 0)
        rows.append({"month": key, "label": month_label(key, "%b"), "full_label": month_label(key), "total": _num(tot), "count": cnt})
    return rows


def monthly_series(df):
    """Continuous month-by-month totals from the first expense to the latest (for the line chart)."""
    if df.empty:
        return []
    g = df.groupby("month")["amount"].sum()
    keys = pd.period_range(g.index.min(), g.index.max(), freq="M").strftime("%Y-%m")
    return [(month_label(k, "%b %y"), float(g.get(k, 0))) for k in keys]


def histogram(df, bins=8):
    if df.empty:
        return {"edges": [], "counts": []}
    counts, edges = np.histogram(df["amount"], bins=bins)
    return {"edges": [float(e) for e in edges], "counts": [int(c) for c in counts]}


def _block(d):
    return {"total": _num(d["amount"].sum()), "count": int(len(d)), "average": round(float(d["amount"].mean()), 2) if len(d) else 0}


def insights(cur, prev, ctx):
    cur_sym = ctx["currency"]
    out = []
    if len(cur):
        s = cur.groupby("category")["amount"].sum().sort_values(ascending=False, kind="mergesort")
        out.append({"icon": "💡", "tone": None, "text": f"You spent {round(s.iloc[0] / s.sum() * 100)}% of this month's expenses on {s.index[0]}."})
        if len(s) > 1:
            out.append({"icon": ctx["emoji"].get(s.index[1], "📦"), "tone": None, "text": f"{s.index[1]} is your second-highest spending category this month."})
    if len(cur) and len(prev):
        ch = pct(cur["amount"].sum(), prev["amount"].sum())
        up = ch >= 0
        out.append({"icon": "📈" if up else "📉", "tone": "warn" if up else "good",
                    "text": f"Your spending {'increased' if up else 'decreased'} by {abs(ch):.0f}% compared with the same days last month."})
        a, b = cur["amount"].mean(), prev["amount"].mean()
        out.append({"icon": "⚠️" if a > b else "✅", "tone": "warn" if a > b else "good",
                    "text": f"Your average expense {'rose' if a > b else 'fell'} from {money_text(b, cur_sym)} to {money_text(a, cur_sym)} this month."})
    return out or [{"icon": "📊", "tone": None, "text": "Add a few expenses this month to see spending insights."}]


def summary(df, today, ctx):
    t = pd.Timestamp(today)
    cm = t.strftime("%Y-%m")
    pm = (t.replace(day=1) - pd.Timedelta(days=1)).strftime("%Y-%m")
    cur = df[df["month"] == cm]
    prev = df[(df["month"] == pm) & (df["date"].dt.day <= t.day)]
    this_m, last_m = _block(cur), _block(prev)
    out = {
        "count": int(len(df)), "total": _num(df["amount"].sum()), "average": round(float(df["amount"].mean()), 2) if len(df) else 0,
        "this_month": this_m, "last_month_same_period": last_m,
        "change_pct": pct(this_m["total"], last_m["total"]),
        "average_change_pct": pct(this_m["average"], last_m["average"]),
        "highest": None, "lowest": None, "top_category": None, "frequent_category": None,
        "daily_average": 0, "monthly_average": 0, "days_span": 0, "months_count": 0,
        "insights": insights(cur, prev, ctx),
    }
    if df.empty:
        return out
    by_cat = df.groupby("category")["amount"].agg(total="sum", n="count").reindex(ctx["names"], fill_value=0)
    span = int((df["date"].max() - df["date"].min()).days) + 1
    months = int(df["month"].nunique())
    total = float(df["amount"].sum())
    top, freq = by_cat["total"].idxmax(), by_cat["n"].idxmax()
    out.update({
        "highest": records(df.loc[[df["amount"].idxmax()]])[0], "lowest": records(df.loc[[df["amount"].idxmin()]])[0],
        "top_category": {"category": top, "total": _num(by_cat.loc[top, "total"])},
        "frequent_category": {"category": freq, "count": int(by_cat.loc[freq, "n"])},
        "days_span": span, "months_count": months,
        "daily_average": round(total / span, 2), "monthly_average": round(total / months, 2),
    })
    return out


def report(df, month, compare, today, names):
    cm = pd.Timestamp(today).strftime("%Y-%m")
    keys = sorted(set(df["month"]) | {cm}, reverse=True)
    month = month or keys[0]
    if not compare:
        compare = keys[keys.index(month) + 1] if month in keys and keys.index(month) + 1 < len(keys) else month

    def block(key):
        d = df[df["month"] == key]
        return {"key": key, "label": month_label(key), **_block(d), **categories(df, names, key)}

    a, b = block(month), block(compare)
    by_b = {c["category"]: c["total"] for c in b["categories"]}
    changes = [{"category": c["category"], "current": c["total"], "previous": by_b[c["category"]], "change_pct": pct(c["total"], by_b[c["category"]])} for c in a["categories"]]
    return {
        "has_data": not df.empty,
        "months": [{"key": k, "label": month_label(k)} for k in keys],
        "month": a, "compare": b, "difference": _num(a["total"] - b["total"]),
        "change_pct": pct(a["total"], b["total"]), "category_changes": changes,
    }
