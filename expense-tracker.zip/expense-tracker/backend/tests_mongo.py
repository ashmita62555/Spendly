"""MongoDB storage tests. They use `mongomock` (an in-memory fake), so no MongoDB server is needed.

    pip install mongomock
    python tests_mongo.py
"""
import json, os, sys, tempfile
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mongomock
from bson import Decimal128
from pymongo.errors import ServerSelectionTimeoutError

from app import create_app
from expense_manager import StorageError
from mongo_manager import MongoExpenseManager, safe_uri
from sample_data import sample_expenses

ok = fail = 0
def check(name, cond, extra=""):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print("FAIL:", name, extra)

def fresh(json_path=None, seed=True):
    client = mongomock.MongoClient()
    col = client["spendly"]["expenses"]
    return col, MongoExpenseManager(col, seed_factory=sample_expenses if seed else None, import_path=json_path)

tmp = tempfile.mkdtemp()

# first run seeds sample data; "initialised" flag stops reseeding after Delete all
col, m = fresh()
check("seeded on first run", col.count_documents({}) > 50)
check("describe", m.describe()["database"] == "spendly" and m.describe()["collection"] == "expenses")
m.clear(); check("cleared", col.count_documents({}) == 0)
m2 = MongoExpenseManager(col, seed_factory=sample_expenses)
check("no reseed after clear + restart", col.count_documents({}) == 0)

# imports the JSON file on first Mongo run
jp = os.path.join(tmp, "old.json")
json.dump([{"id": 7, "date": "2026-01-02", "category": "Food", "amount": 50, "description": "From JSON"}], open(jp, "w"))
col, m = fresh(jp)
check("json import", [i["description"] for i in m.all()] == ["From JSON"] and m.all()[0]["id"] == 7)
check("next id after import", m.add({"date": "2026-01-03", "category": "Food", "amount": 5, "description": "n"})["id"] == 8)

# CRUD + ids never reused
col, m = fresh()
a = m.add({"date": "2026-10-05", "category": "Food", "amount": "450", "description": " Lunch  out "})
check("add", a["description"] == "Lunch out" and a["amount"] == 450)
check("stored shape", set(col.find_one({"id": a["id"]}).keys()) == {"_id", "id", "date", "category", "amount", "description"})
u = m.update(a["id"], {"date": "2026-10-04", "category": "travel", "amount": 99.5, "description": "Bus"})
check("update", u["category"] == "Travel" and m.get(a["id"])["amount"] == 99.5)
m.delete(a["id"])
b = m.add({"date": "2026-10-05", "category": "Food", "amount": 10, "description": "x"})
check("ids not reused", b["id"] > a["id"])
for fn, label in ((lambda: m.get(999999), "get"), (lambda: m.delete(999999), "delete"), (lambda: m.update(999999, {"date": "2026-10-04", "category": "Food", "amount": 5, "description": "x"}), "update")):
    try: fn(); check(label + " missing", False)
    except Exception as e: check(label + " missing -> NotFound", type(e).__name__ == "NotFoundError")

# documents typed by hand in Compass
col = mongomock.MongoClient()["spendly"]["expenses"]
col.insert_many([
    {"date": "2026-10-01", "category": "Food", "amount": 120, "description": "No id at all"},
    {"id": 5.0, "date": datetime(2026, 10, 2), "category": "bills", "amount": Decimal128("250.50"), "description": "BSON date + Decimal128", "extra": "kept"},
    {"id": 5, "date": "2026-10-03", "category": "Health", "amount": 80, "description": "Duplicate id"},
    {"date": "garbage", "category": "Food", "amount": 1, "description": "invalid date"},
    {"date": "2026-10-04", "category": "Food", "amount": -5, "description": "negative amount"},
])
m = MongoExpenseManager(col)  # documents existed before the app first connected (index creation may fail on duplicates)
items = m.all()
check("repairs + skips", sorted(i["description"] for i in items) == ["BSON date + Decimal128", "Duplicate id", "No id at all"], items)
check("ids unique", len({i["id"] for i in items}) == 3)
check("normalised", next(i for i in items if i["id"] == 5)["amount"] == 250.5 and next(i for i in items if i["id"] == 5)["category"] == "Bills")
check("repairs persisted", all(isinstance(d.get("id"), int) for d in col.find({"description": {"$in": ["No id at all", "Duplicate id"]}})))
check("extra fields untouched", col.find_one({"description": "BSON date + Decimal128"}).get("extra") == "kept")
new = m.add({"date": "2026-10-05", "category": "Food", "amount": 5, "description": "after repair"})
check("add after repair gets a fresh id", new["id"] not in {i["id"] for i in items})

# edits made in Compass bump the chart-cache version
m.all(); v1 = m.mtime_ns; m.all(); check("version stable when unchanged", m.mtime_ns == v1)
col.update_one({"description": "after repair"}, {"$set": {"amount": 6}}); m.all()
check("version bumps on external edit", m.mtime_ns > v1)

# full API on top of Mongo
col, m = fresh()
app = create_app(manager=m, charts_dir=os.path.join(tmp, "charts")); c = app.test_client()
h = c.get("/api/health").json
check("health reports mongo", h["status"] == "ok" and h["storage"]["type"] == "mongodb" and h["expenses"] > 50, h)
r = c.post("/api/expenses", json={"date": "2026-10-05", "category": "Food", "amount": 450, "description": "API test"}); check("api create", r.status_code == 201)
eid = r.json["expense"]["id"]
check("api list + search", c.get("/api/expenses?q=api%20test").json["count"] == 1)
check("api put", c.put(f"/api/expenses/{eid}", json={"date": "2026-10-05", "category": "Food", "amount": 500, "description": "API test 2"}).json["expense"]["amount"] == 500)
check("api bad amount", c.post("/api/expenses", json={"date": "2026-10-05", "category": "Food", "amount": "abc", "description": "x"}).status_code == 400)
check("api delete", c.delete(f"/api/expenses/{eid}").status_code == 200 and c.delete(f"/api/expenses/{eid}").status_code == 404)
check("api summary", c.get("/api/analytics/summary").json["count"] > 50)
ch = c.get("/api/analytics/charts?theme=light&size=compact").json
check("compact charts", len(ch["charts"]) == 4 and all("_compact" in x["url"] for x in ch["charts"]) and c.get(ch["charts"][0]["url"]).status_code == 200)
check("bad chart size", c.get("/api/analytics/charts?size=huge").status_code == 400)
check("sample reload", c.post("/api/expenses/sample").json["loaded"] > 50 and c.delete("/api/expenses?confirm=true").json["deleted"] > 50)

# database goes down mid-flight: friendly 500, never a stack trace
class Broken:
    database = col.database; name = "expenses"
    def __getattr__(self, n):
        def boom(*a, **k): raise ServerSelectionTimeoutError("connection refused")
        return boom
m._col = Broken()
r = c.get("/api/expenses")
check("db down -> friendly 500", r.status_code == 500 and "MongoDB" in r.json["error"] and "Traceback" not in r.get_data(as_text=True), r.json)
r = c.get("/api/health"); check("health 503 when db down", r.status_code == 503 and r.json["status"] == "error")
r = c.post("/api/expenses", json={"date": "2026-10-05", "category": "Food", "amount": 5, "description": "x"}); check("write when down", r.status_code == 500 and r.is_json)

check("safe_uri hides password", safe_uri("mongodb+srv://user:secret@cluster0.mongodb.net/x") == "mongodb+srv://***@cluster0.mongodb.net/x" and safe_uri("mongodb://localhost:27017") == "mongodb://localhost:27017")

# build_manager falls back to JSON when MongoDB is not running
os.environ["MONGODB_URI"] = "mongodb://127.0.0.1:1"
import app as appmod
mgr, note = appmod.build_manager(os.path.join(tmp, "fallback.json"))
check("fallback to json with a note", mgr.kind == "json" and note and "MongoDB" in note)
os.environ["STORAGE"] = "json"
mgr, note = appmod.build_manager(os.path.join(tmp, "forced.json")); check("STORAGE=json", mgr.kind == "json" and note is None)

print(f"\n{ok} passed, {fail} failed"); sys.exit(1 if fail else 0)
