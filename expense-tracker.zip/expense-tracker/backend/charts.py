"""Matplotlib chart generation. Kept separate from business logic: it only draws what analytics.py computes.

Two sizes: "wide" for desktop/tablet and "compact" (taller, larger text) so charts stay readable on phones.
"""
from __future__ import annotations

import threading
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # no GUI needed on a server
from matplotlib.figure import Figure  # noqa: E402
from matplotlib.ticker import FuncFormatter, MaxNLocator  # noqa: E402

import analytics  # noqa: E402

THEMES = {
    "light": {"bg": "#ffffff", "fg": "#0b1437", "muted": "#64748b", "grid": "#e4e8f3", "accent": "#4f46e5"},
    "dark": {"bg": "#111936", "fg": "#e8ecfb", "muted": "#8f9ac7", "grid": "#212b52", "accent": "#818cf8"},
}
SIZES = {"wide": {"figsize": (8, 4.4), "dpi": 140, "k": 1.0}, "compact": {"figsize": (4.8, 4.6), "dpi": 150, "k": 1.3}}
CHARTS = [("bar", "Category-wise expenditure"), ("pie", "Spending distribution"),
          ("line", "Spending over time"), ("histogram", "Expense amount distribution")]
_lock = threading.Lock()  # Matplotlib is not fully thread-safe


def _short(v, sym):
    if sym == "₹" and v >= 1e5:
        return f"{sym}{v / 1e5:g}L"
    if v >= 1e6:
        return f"{sym}{v / 1e6:g}M"
    return f"{sym}{v / 1e3:g}k" if v >= 1e3 else f"{sym}{v:g}"


def _canvas(theme, title, size, axes=True):
    t, cfg = THEMES[theme], SIZES[size]
    k = cfg["k"]
    fig = Figure(figsize=cfg["figsize"], dpi=cfg["dpi"], facecolor=t["bg"])
    if not axes:
        fig.text(0.05, 0.93, title, color=t["fg"], fontsize=13 * min(k, 1.15), fontweight="bold", ha="left")
        return fig, None, t, k
    ax = fig.add_subplot(111)
    ax.set_facecolor(t["bg"])
    ax.set_title(title, loc="left", color=t["fg"], fontsize=13 * min(k, 1.15), fontweight="bold", pad=14)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(t["grid"])
    ax.tick_params(colors=t["muted"], labelsize=9 * k, length=0)
    ax.grid(axis="y", color=t["grid"], linestyle="--", linewidth=0.7)
    ax.set_axisbelow(True)
    if size == "compact":
        fig.subplots_adjust(left=0.19, right=0.97, top=0.86, bottom=0.25)
    else:
        fig.subplots_adjust(left=0.1, right=0.97, top=0.85, bottom=0.17)
    return fig, ax, t, k


def _no_data(fig, t, k):
    fig.text(0.5, 0.45, "No expenses yet", color=t["muted"], fontsize=13 * k, ha="center")


def _bar(df, theme, size, ctx):
    sym, colors = ctx["currency"]["symbol"], ctx["colors"]
    fig, ax, t, k = _canvas(theme, CHARTS[0][1], size)
    cats = analytics.categories(df, ctx["names"])["categories"]
    if not len(df):
        _no_data(fig, t, k)
        return fig
    bars = ax.bar([c["category"] for c in cats], [c["total"] for c in cats], color=[colors.get(c["category"], "#64748b") for c in cats], width=0.62)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _short(v, sym)))
    top = max(c["total"] for c in cats)
    if size == "wide":
        for b, c in zip(bars, cats):
            if c["total"]:
                ax.text(b.get_x() + b.get_width() / 2, c["total"] + top * 0.015, analytics.money_text(c["total"], ctx["currency"]), ha="center", va="bottom", color=t["fg"], fontsize=8, fontweight="bold")
        ax.tick_params(axis="x", labelsize=8)
    else:
        ax.tick_params(axis="x", labelsize=9, rotation=40)
        for lbl in ax.get_xticklabels():
            lbl.set_ha("right")
    ax.set_ylim(0, top * 1.15)
    return fig


def _pie(df, theme, size, ctx):
    sym, colors = ctx["currency"]["symbol"], ctx["colors"]
    fig, _, t, k = _canvas(theme, CHARTS[1][1], size, axes=False)
    data = [c for c in analytics.categories(df, ctx["names"])["categories"] if c["total"] > 0]
    if not data:
        _no_data(fig, t, k)
        return fig
    wide = size == "wide"
    ax = fig.add_axes([0.04, 0.06, 0.5, 0.8] if wide else [0.12, 0.34, 0.76, 0.54])
    ax.pie([c["total"] for c in data], colors=[colors.get(c["category"], "#64748b") for c in data], startangle=90, counterclock=False,
           wedgeprops={"width": 0.42, "edgecolor": t["bg"], "linewidth": 2})
    ax.text(0, 0.07, analytics.money_text(sum(c["total"] for c in data), ctx["currency"]), ha="center", color=t["fg"], fontsize=14 if wide else 15, fontweight="bold")
    ax.text(0, -0.17, "total spent", ha="center", color=t["muted"], fontsize=8 if wide else 10)
    labels = [f"{c['category']}  {c['share']:.1f}%" for c in data]
    if wide:
        leg = fig.legend(labels, loc="center left", bbox_to_anchor=(0.58, 0.46), frameon=False, fontsize=10, labelcolor=t["fg"])
    else:
        leg = fig.legend(labels, loc="lower center", bbox_to_anchor=(0.5, 0.01), ncol=2, frameon=False, fontsize=9.5, labelcolor=t["fg"], columnspacing=1.2)
    for handle, c in zip(leg.legend_handles, data):
        handle.set_facecolor(colors.get(c["category"], "#64748b"))
    return fig


def _line(df, theme, size, ctx):
    sym, colors = ctx["currency"]["symbol"], ctx["colors"]
    fig, ax, t, k = _canvas(theme, CHARTS[2][1], size)
    series = analytics.monthly_series(df)
    if not series:
        _no_data(fig, t, k)
        return fig
    labels, vals = [s[0] for s in series], [s[1] for s in series]
    xs = list(range(len(vals)))
    ax.plot(xs, vals, color=t["accent"], linewidth=2.6, marker="o", markersize=6, markerfacecolor=t["bg"], markeredgewidth=2)
    ax.fill_between(xs, vals, color=t["accent"], alpha=0.12)
    step = 1 if size == "wide" or len(xs) <= 6 else 2  # thin out month labels on phones
    ax.set_xticks(xs[::step], labels[::step])
    ax.set_xlim(-0.3, max(len(xs) - 1, 1) + 0.3)
    ax.set_ylim(0, max(vals) * 1.18 or 1)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _short(v, sym)))
    if size == "wide" or len(xs) <= 6:
        for x, v in zip(xs, vals):
            ax.annotate(_short(v, sym), (x, v), textcoords="offset points", xytext=(0, 9), ha="center", color=t["fg"], fontsize=8 * k, fontweight="bold")
    return fig


def _hist(df, theme, size, ctx):
    sym, colors = ctx["currency"]["symbol"], ctx["colors"]
    fig, ax, t, k = _canvas(theme, CHARTS[3][1], size)
    h = analytics.histogram(df)
    if not h["counts"]:
        _no_data(fig, t, k)
        return fig
    e, c = h["edges"], h["counts"]
    mids = [(e[i] + e[i + 1]) / 2 for i in range(len(c))]
    ax.bar(mids, c, width=[(e[i + 1] - e[i]) * 0.9 for i in range(len(c))], color=t["accent"])
    ax.set_xlabel("Expense amount", color=t["muted"], fontsize=9 * k)
    ax.set_ylabel("Number of expenses", color=t["muted"], fontsize=9 * k)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: _short(v, sym)))
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    if size == "compact":
        ax.xaxis.set_major_locator(MaxNLocator(4))
    for x, v in zip(mids, c):
        ax.text(x, v, str(v), ha="center", va="bottom", color=t["fg"], fontsize=8 * k)
    return fig


_DRAW = {"bar": _bar, "pie": _pie, "line": _line, "histogram": _hist}


def generate_all(df, theme, out_dir, data_mtime_ns, size, ctx):
    """Create (or reuse) the four PNGs for a theme and size. Returns [{id, title, filename, mtime_ns}]."""
    if theme not in THEMES or size not in SIZES:
        raise ValueError("Unknown theme or size")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = "" if size == "wide" else f"_{size}"
    result = []
    with _lock:
        for cid, title in CHARTS:
            path = out_dir / f"{cid}_{theme}{suffix}.png"
            if not path.exists() or path.stat().st_mtime_ns < data_mtime_ns:
                fig = _DRAW[cid](df, theme, size, ctx)
                fig.savefig(path, facecolor=fig.get_facecolor())
            result.append({"id": cid, "title": title, "filename": path.name, "mtime_ns": path.stat().st_mtime_ns})
    return result
