"""MongoDB storage. Same interface as ExpenseManager, so the rest of the app doesn't care which one is used.

Collections in the database (open them in MongoDB Compass):
  expenses  one document per expense: {id, date, category, amount, description}
  counters  keeps the next numeric id (so ids are never reused)
  meta      remembers that first-run setup is done
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError

from expense_manager import CATEGORIES, ExpenseManager, NotFoundError, StorageError, clean_expense, coerce_record

log = logging.getLogger("expenses.mongo")
DB_DOWN = "Unable to reach the database. Is MongoDB running?"


def safe_uri(uri: str) -> str:
    """Hide any username:password in a connection string."""
    return re.sub(r"//[^@/]*@", "//***@", uri)


class MongoExpenseManager:
    kind = "mongodb"

    def __init__(self, collection, seed_factory=None, import_path=None, uri="mongodb://localhost:27017"):
        self._col = collection
        db = collection.database
        self._counters = db["counters"]
        self._meta = db["meta"]
        self._uri = uri
        self.category_names = lambda: list(CATEGORIES)  # replaced by the app with the live, editable list
        self._lock = threading.RLock()
        self._fingerprint = None
        self._version_ns = time.time_ns()
        with self._guard():
            self._ensure_indexes()
            self._first_run(seed_factory, import_path)
            self._sync_counter()

    # ---- plumbing ------------------------------------------------------
    @contextmanager
    def _guard(self):
        try:
            yield
        except PyMongoError as exc:
            log.error("MongoDB error: %s", exc)
            raise StorageError(DB_DOWN) from exc

    def describe(self) -> dict:
        return {"type": "mongodb", "label": "MongoDB", "database": self._col.database.name,
                "collection": self._col.name, "uri": safe_uri(self._uri)}

    def config_backend(self):
        from config_store import MongoConfigBackend
        return MongoConfigBackend(self._col.database["config"])

    def rename_category(self, old: str, new: str) -> int:
        """Move every expense from category `old` to `new` (used for renames and for delete-with-reassign)."""
        with self._lock, self._guard():
            match = {"category": {"$regex": f"^{re.escape(old)}$", "$options": "i"}}
            return self._col.update_many(match, {"$set": {"category": new}}).modified_count

    @property
    def mtime_ns(self) -> int:
        """Changes whenever the data changes (also when edited directly in Compass). Used to refresh chart PNGs."""
        return self._version_ns

    def _ensure_indexes(self):
        try:
            self._col.create_index("id", unique=True, partialFilterExpression={"id": {"$type": "number"}})
            self._col.create_index("date")
        except Exception as exc:  # indexes are a safety net, not required
            log.warning("Could not create indexes: %s", exc)

    def _first_run(self, seed_factory, import_path):
        state = self._meta.find_one({"_id": "state"})
        if state and state.get("initialised"):
            return
        if self._col.count_documents({}) == 0:
            items = self._import_json(import_path) or (seed_factory() if seed_factory else [])
            if items:
                self._col.insert_many([dict(i) for i in items])
                log.info("Added %d starter expenses to MongoDB", len(items))
        self._meta.update_one({"_id": "state"}, {"$set": {"initialised": True}}, upsert=True)

    @staticmethod
    def _import_json(path):
        """If you used the JSON version before, bring that data across on the first MongoDB run."""
        if path and Path(path).exists():
            try:
                items = ExpenseManager(path).all()
            except Exception:
                return []
            if items:
                log.info("Importing %d expenses from %s", len(items), path)
                return items
        return []

    def _sync_counter(self, extra_max=0):
        mx = extra_max
        for d in self._col.find({}, {"id": 1}):
            v = d.get("id")
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                mx = max(mx, int(v))
        cur = self._counters.find_one({"_id": "expenses"})
        if not cur or cur.get("seq", 0) < mx:
            self._counters.update_one({"_id": "expenses"}, {"$set": {"seq": mx}}, upsert=True)

    def _next_id(self) -> int:
        doc = self._counters.find_one_and_update({"_id": "expenses"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
        return int(doc["seq"])

    # ---- reads ---------------------------------------------------------
    def all(self) -> list:
        with self._lock, self._guard():
            items, seen, repairs, names = [], set(), [], self.category_names()
            for doc in self._col.find({}):
                res = coerce_record(doc, names)
                if res is None:
                    log.warning("Skipping invalid document %s", doc.get("_id"))
                    continue
                clean, rid = res
                if rid is None or rid in seen:  # e.g. a document added by hand in Compass without an id
                    repairs.append((doc["_id"], clean))
                    continue
                seen.add(rid)
                items.append({"id": rid, **clean})
            if repairs:
                self._sync_counter(max(seen, default=0))
                for _id, clean in repairs:
                    new_id = self._next_id()
                    self._col.update_one({"_id": _id}, {"$set": {"id": new_id}})
                    items.append({"id": new_id, **clean})
            items.sort(key=lambda i: i["id"])
            fp = hash(json.dumps(items, sort_keys=True))
            if fp != self._fingerprint:
                self._fingerprint, self._version_ns = fp, time.time_ns()
            return items

    def get(self, expense_id: int) -> dict:
        with self._guard():
            doc = self._col.find_one({"id": expense_id})
        res = coerce_record(doc, self.category_names()) if doc else None
        if not res:
            raise NotFoundError(f"Expense {expense_id} was not found.")
        return {"id": expense_id, **res[0]}

    # ---- writes --------------------------------------------------------
    def add(self, data) -> dict:
        clean = clean_expense(data, categories=self.category_names())
        with self._lock, self._guard():
            for _ in range(5):
                new = {"id": self._next_id(), **clean}
                try:
                    self._col.insert_one(dict(new))
                    return new
                except DuplicateKeyError:  # someone added an id by hand; catch the counter up and retry
                    self._sync_counter()
        raise StorageError("Unable to save your changes.")

    def update(self, expense_id: int, data) -> dict:
        clean = clean_expense(data, categories=self.category_names())
        with self._lock, self._guard():
            res = self._col.update_one({"id": expense_id}, {"$set": clean})
            if res.matched_count == 0:
                raise NotFoundError(f"Expense {expense_id} was not found.")
        return {"id": expense_id, **clean}

    def delete(self, expense_id: int) -> None:
        with self._lock, self._guard():
            if self._col.delete_one({"id": expense_id}).deleted_count == 0:
                raise NotFoundError(f"Expense {expense_id} was not found.")

    def clear(self) -> int:
        with self._lock, self._guard():
            return self._col.delete_many({}).deleted_count

    def replace_all(self, items: list) -> int:
        with self._lock, self._guard():
            self._col.delete_many({})
            if items:
                self._col.insert_many([dict(i) for i in items])
            self._sync_counter()
            return len(items)
