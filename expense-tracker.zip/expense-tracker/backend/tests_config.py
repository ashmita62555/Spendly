"""Tests for the editable configuration: settings, currency and categories (JSON and MongoDB storage).

    pip install mongomock
    python tests_config.py
"""
import json, os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mongomock

from app import create_app
from expense_manager import ExpenseManager
from mongo_manager import MongoExpenseManager
from sample_data import sample_expenses

ok = fail = 0
def check(name, cond, extra=""):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print("FAIL:", name, extra)

GOOD = {"date": "2026-10-05", "category": "Food", "amount": 100, "description": "t"}

def suite(label, make):
    p = lambda n: f"[{label}] {n}"
    app, reopen = make(); c = app.test_client()
    cfg = c.get("/api/config").json
    check(p("config shape"), len(cfg["categories"]) == 8 and cfg["settings"]["currency"] == "INR" and cfg["currency"]["symbol"] == "₹" and len(cfg["currencies"]) >= 4 and "storage" in cfg, cfg)

    # settings
    r = c.put("/api/settings", json={"display_name": "  Asha   K ", "tagline": "Family plan", "app_name": "MyMoney", "currency": "USD", "theme": "dark", "sidebar_collapsed": True})
    check(p("save settings"), r.status_code == 200 and r.json["settings"]["display_name"] == "Asha K" and r.json["currency"]["symbol"] == "$" and r.json["settings"]["sidebar_collapsed"] is True, r.json)
    for bad in ({"display_name": ""}, {"display_name": "x" * 31}, {"currency": "XXX"}, {"theme": "neon"}, {"sidebar_collapsed": "yes"}, {"app_name": "   "}):
        rr = c.put("/api/settings", json=bad); check(p(f"bad setting {bad}"), rr.status_code == 400 and rr.json["fields"], rr.json)
    check(p("bad body"), c.put("/api/settings", data="nope", content_type="application/json").status_code == 400)
    app2, _ = reopen(); c2 = app2.test_client()
    check(p("settings persist across restart"), c2.get("/api/config").json["settings"]["display_name"] == "Asha K" and c2.get("/api/config").json["settings"]["theme"] == "dark")

    # currency drives analytics text + chart cache
    s = c.get("/api/analytics/summary").json
    avg_lines = [i["text"] for i in s["insights"] if "average expense" in i["text"]]
    check(p("insights use the chosen currency"), not avg_lines or ("$" in avg_lines[0] and "₹" not in avg_lines[0]), avg_lines)
    v1 = c.get("/api/analytics/charts?theme=light").json["charts"][0]["url"]
    c.put("/api/settings", json={"currency": "EUR"})
    v2 = c.get("/api/analytics/charts?theme=light").json["charts"][0]["url"]
    check(p("chart cache refreshes when config changes"), v1 != v2, (v1, v2))
    c.put("/api/settings", json={"currency": "INR"})

    # categories: add / validate
    r = c.post("/api/categories", json={"name": "Gym", "emoji": "🏋️", "color": "#10B981"})
    check(p("add category"), r.status_code == 201 and r.json["category"] == {"name": "Gym", "emoji": "🏋️", "color": "#10b981"}, r.json)
    check(p("empty emoji gets a default"), c.post("/api/categories", json={"name": "Pets", "color": "#112233"}).json["category"]["emoji"] == "🏷️")
    for bad, field in (({"name": "gym", "emoji": "🏋️", "color": "#000000"}, "name"), ({"name": "", "color": "#000000"}, "name"), ({"name": "A<b>", "color": "#000000"}, "name"),
                       ({"name": "X" * 21, "color": "#000000"}, "name"), ({"name": "Okay", "color": "red"}, "color"), ({"name": "Okay", "emoji": "abc", "color": "#000000"}, "emoji")):
        rr = c.post("/api/categories", json=bad); check(p(f"bad category {bad}"), rr.status_code == 400 and field in rr.json["fields"], rr.json)
    check(p("new category usable for expenses"), c.post("/api/expenses", json={**GOOD, "category": "gym", "description": "Membership"}).json["expense"]["category"] == "Gym")
    check(p("unknown category rejected"), c.post("/api/expenses", json={**GOOD, "category": "Nope"}).status_code == 400)
    check(p("categories list has counts"), next(x for x in c.get("/api/categories").json["categories"] if x["name"] == "Gym")["count"] == 1)
    check(p("analytics include the new category"), any(x["category"] == "Gym" for x in c.get("/api/analytics/categories").json["categories"]))

    # rename cascades
    food = c.get("/api/expenses?category=Food&per_page=100").json["count"]
    r = c.put("/api/categories/Food", json={"name": "Meals", "emoji": "🍽️"})
    check(p("rename category"), r.status_code == 200 and r.json["category"]["name"] == "Meals" and r.json["category"]["color"] == "#f59e0b", r.json)
    check(p("rename moved the expenses"), c.get("/api/expenses?category=Meals&per_page=100").json["count"] == food and c.get("/api/expenses?category=Food").status_code == 400)
    check(p("rename to an existing name rejected"), c.put("/api/categories/Meals", json={"name": "travel"}).status_code == 400)
    check(p("recolor only"), c.put("/api/categories/Meals", json={"color": "#abcdef"}).json["category"]["color"] == "#abcdef")
    check(p("update unknown 404"), c.put("/api/categories/Zzz", json={"name": "Q"}).status_code == 404)
    check(p("old expenses still all visible"), c.get("/api/expenses").json["overall_count"] == len(sample_expenses()) + 1)

    # delete
    r = c.delete("/api/categories/Meals"); check(p("delete needs reassign target"), r.status_code == 400 and "move the" in r.json["error"], r.json)
    r = c.delete("/api/categories/Meals?reassign_to=Meals"); check(p("cannot reassign to itself"), r.status_code == 400)
    r = c.delete("/api/categories/Meals?reassign_to=other"); check(p("delete with reassign"), r.status_code == 200 and r.json["moved"] == food, r.json)
    check(p("expenses moved to target"), c.get("/api/expenses?category=Other&per_page=100").json["count"] >= food)
    check(p("empty category deletes without target"), c.delete("/api/categories/Pets").status_code == 200)
    check(p("delete unknown 404"), c.delete("/api/categories/Pets").status_code == 404)

    # sample reload after removing a default category still works
    c.delete("/api/categories/Bills?reassign_to=Other")
    r = c.post("/api/expenses/sample"); check(p("sample data adapts to your categories"), r.status_code == 200 and c.get("/api/expenses").json["overall_count"] == r.json["loaded"], r.json)

    # cannot delete the last category
    names = [x["name"] for x in c.get("/api/categories").json["categories"]]
    for n in names[:-1]: c.delete(f"/api/categories/{n}?reassign_to={names[-1]}")
    r = c.delete(f"/api/categories/{names[-1]}?reassign_to={names[-1]}"); check(p("last category is protected"), r.status_code == 400)

    # a bad hand-edit of the stored config falls back safely
    return app, c

def make_json():
    d = tempfile.mkdtemp(); f = os.path.join(d, "expenses.json"); charts = os.path.join(d, "charts")
    return create_app(data_file=f, charts_dir=charts), lambda: (create_app(data_file=f, charts_dir=charts), None)

def make_mongo():
    d = tempfile.mkdtemp(); col = mongomock.MongoClient()["spendly"]["expenses"]; charts = os.path.join(d, "charts")
    mk = lambda: create_app(manager=MongoExpenseManager(col, seed_factory=sample_expenses), charts_dir=charts)
    return mk(), lambda: (mk(), None)

def make(factory):
    app, reopen = factory()
    return app, reopen

app, c = suite("json", make_json)
suite("mongo", make_mongo)

# hand-edited config in MongoDB / JSON never crashes the app
col = mongomock.MongoClient()["spendly"]["expenses"]
app = create_app(manager=MongoExpenseManager(col, seed_factory=sample_expenses), charts_dir=tempfile.mkdtemp()); c = app.test_client()
col.database["config"].replace_one({"_id": "app"}, {"_id": "app", "settings": {"display_name": 5, "currency": "ZZZ", "theme": "dark"}, "categories": [{"name": "Okay", "color": "#fff"}, "junk", {"name": "Fine", "emoji": "🍕", "color": "#123456"}, {"name": "fine", "color": "#123456"}]})
cfg = c.get("/api/config").json
check("bad stored config falls back per field", cfg["settings"]["currency"] == "INR" and cfg["settings"]["display_name"] == "Subham" and cfg["settings"]["theme"] == "dark", cfg["settings"])
check("bad stored categories filtered", [x["name"] for x in cfg["categories"]] == ["Fine"], cfg["categories"])
check("app still serves data", c.get("/api/analytics/summary").status_code == 200)

d = tempfile.mkdtemp(); f = os.path.join(d, "expenses.json"); app = create_app(data_file=f, charts_dir=d); c = app.test_client()
open(os.path.join(d, "config.json"), "w").write("{ broken json")
check("corrupt config.json -> defaults", len(c.get("/api/config").json["categories"]) == 8)

print(f"\n{ok} passed, {fail} failed"); sys.exit(1 if fail else 0)
