"""Expense storage (JSON file) and validation.

Pure Python: no Flask or Pandas in here, so it is easy to test on its own.
The backend never trusts the browser, so every write goes through clean_expense().
"""
from __future__ import annotations

import json
import logging
import math
import os
import re
import tempfile
import threading
import time
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

log = logging.getLogger("expenses")

CATEGORIES = ["Food", "Travel", "Education", "Shopping", "Entertainment", "Bills", "Health", "Other"]
CATEGORY_LOOKUP = {c.lower(): c for c in CATEGORIES}
MAX_AMOUNT = 10_000_000
MAX_DESCRIPTION = 80
MIN_DATE = date(2000, 1, 1)

_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_AMOUNT_RE = re.compile(r"\d+(\.\d{1,2})?")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]+")


class ValidationError(Exception):
    """Raised with a {field: friendly message} dict."""

    def __init__(self, fields: dict):
        super().__init__("; ".join(fields.values()))
        self.fields = fields


class NotFoundError(Exception):
    pass


class StorageError(Exception):
    pass


def clean_expense(data, today: date | None = None, allow_future: bool = False, categories=None) -> dict:
    """Validate and normalise one expense. Returns a clean dict (without id).

    `categories` is the live list of category names (they are editable in Settings); defaults to the built-in list."""
    if not isinstance(data, dict):
        raise ValidationError({"_": "Request body must be a JSON object."})
    today = today or date.today()
    errors: dict = {}
    clean: dict = {}

    # date
    raw = data.get("date")
    try:
        if not isinstance(raw, str) or not _DATE_RE.fullmatch(raw.strip()):
            raise ValueError
        d = datetime.strptime(raw.strip(), "%Y-%m-%d").date()
        if d < MIN_DATE:
            raise ValueError
    except ValueError:
        errors["date"] = "Please choose a valid date."
    else:
        if d > today and not allow_future:
            errors["date"] = "The date can't be in the future."
        else:
            clean["date"] = d.isoformat()

    # category
    cat = data.get("category")
    lookup = {c.lower(): c for c in (categories if categories is not None else CATEGORIES)}
    canonical = lookup.get(cat.strip().lower()) if isinstance(cat, str) else None
    if canonical:
        clean["category"] = canonical
    else:
        errors["category"] = "Please select a category."

    # amount
    raw = data.get("amount")
    amount = None
    if isinstance(raw, bool) or raw is None:
        pass
    elif isinstance(raw, (int, float)):
        if math.isfinite(raw):
            amount = round(float(raw), 2)
    elif isinstance(raw, str) and _AMOUNT_RE.fullmatch(raw.strip()):
        amount = float(raw.strip())
    if amount is None:
        errors["amount"] = "Please enter a valid expense amount, using numbers only (for example 500 or 99.50)."
    elif amount <= 0:
        errors["amount"] = "The amount must be greater than 0."
    elif amount > MAX_AMOUNT:
        errors["amount"] = "That amount is too large."
    else:
        clean["amount"] = int(amount) if amount.is_integer() else amount

    # description (control characters removed; HTML is escaped by the frontend on display)
    desc = data.get("description")
    desc = " ".join(_CONTROL_RE.sub(" ", desc).split()) if isinstance(desc, str) else ""
    if not desc:
        errors["description"] = "Please add a short description."
    elif len(desc) > MAX_DESCRIPTION:
        errors["description"] = f"Keep the description under {MAX_DESCRIPTION} characters."
    else:
        clean["description"] = desc

    if errors:
        raise ValidationError(errors)
    return clean


def coerce_record(rec, categories=None):
    """Read one stored record (a JSON entry or a MongoDB document).

    Returns (clean_fields, id_or_None), or None if the record is unusable.
    Tolerates values typed by hand in MongoDB Compass: BSON dates, Decimal128, ids stored as doubles.
    """
    if not isinstance(rec, dict):
        return None
    raw = {k: rec.get(k) for k in ("date", "category", "amount", "description")}
    d = raw["date"]
    if isinstance(d, datetime):
        raw["date"] = d.date().isoformat()
    elif isinstance(d, date):
        raw["date"] = d.isoformat()
    a = raw["amount"]
    try:
        if hasattr(a, "to_decimal"):  # bson.Decimal128
            a = a.to_decimal()
        if isinstance(a, Decimal):
            a = float(a)
    except (ValueError, ArithmeticError):
        return None
    raw["amount"] = a
    try:
        clean = clean_expense(raw, allow_future=True, categories=categories)
    except ValidationError:
        return None
    rid = rec.get("id")
    if isinstance(rid, float) and rid.is_integer():
        rid = int(rid)
    if isinstance(rid, bool) or not isinstance(rid, int) or rid < 1:
        rid = None
    return clean, rid


class ExpenseManager:
    """Thread-safe CRUD on a JSON file with atomic writes."""

    kind = "json"

    def __init__(self, path, seed_factory=None):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._items: list = []
        self.category_names = lambda: list(CATEGORIES)  # replaced by the app with the live, editable list
        self._mtime = None
        self.recovered_from_corruption = False
        with self._lock:
            if not self.path.exists():
                self._items = seed_factory() if seed_factory else []
                self._write(self._items)
                log.info("Created %s with %d expenses", self.path, len(self._items))
            else:
                self._load()

    def describe(self) -> dict:
        return {"type": "json", "label": "JSON file", "path": str(self.path)}

    def config_backend(self):
        from config_store import JsonConfigBackend
        return JsonConfigBackend(self.path.with_name("config.json"))

    def rename_category(self, old: str, new: str) -> int:
        """Move every expense from category `old` to `new` (used for renames and for delete-with-reassign)."""
        with self._lock:
            self._refresh()
            n = sum(1 for i in self._items if i["category"].lower() == old.lower())
            if n:
                self._commit([{**i, "category": new} if i["category"].lower() == old.lower() else i for i in self._items])
            return n

    # ---- file handling -------------------------------------------------
    @property
    def mtime_ns(self) -> int:
        try:
            return self.path.stat().st_mtime_ns
        except OSError:
            return 0

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                raise ValueError("expenses file must contain a JSON list")
        except (OSError, ValueError) as exc:  # json.JSONDecodeError is a ValueError
            backup = self.path.with_name(f"{self.path.stem}.corrupt-{int(time.time())}{self.path.suffix}")
            try:
                os.replace(self.path, backup)
                log.warning("Unreadable %s (%s). Moved to %s and starting empty.", self.path, exc, backup)
            except OSError:
                log.warning("Unreadable %s (%s). Starting empty.", self.path, exc)
            self.recovered_from_corruption = True
            self._items = []
            self._write(self._items)
            return
        items, seen, names = [], set(), self.category_names()
        for rec in raw:
            res = coerce_record(rec, names)
            if res is None or res[1] is None or res[1] in seen:
                log.warning("Skipping invalid record: %r", rec)
                continue
            seen.add(res[1])
            items.append({"id": res[1], **res[0]})
        self._items = items
        self._mtime = self.mtime_ns

    def _refresh(self):
        """Pick up manual edits to the file while the server is running."""
        if self.mtime_ns != self._mtime:
            self._load()

    def _write(self, items):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".expenses-", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(items, f, indent=2, ensure_ascii=False)
                os.replace(tmp, self.path)
            except BaseException:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
        except OSError as exc:
            log.error("Could not save %s: %s", self.path, exc)
            raise StorageError("Unable to save your changes.") from exc
        self._mtime = self.mtime_ns

    def _commit(self, new_items):
        self._write(new_items)
        self._items = new_items

    # ---- CRUD ----------------------------------------------------------
    def all(self) -> list:
        with self._lock:
            self._refresh()
            return [dict(i) for i in self._items]

    def get(self, expense_id: int) -> dict:
        with self._lock:
            self._refresh()
            for item in self._items:
                if item["id"] == expense_id:
                    return dict(item)
        raise NotFoundError(f"Expense {expense_id} was not found.")

    def add(self, data) -> dict:
        clean = clean_expense(data, categories=self.category_names())
        with self._lock:
            self._refresh()
            new = {"id": max((i["id"] for i in self._items), default=0) + 1, **clean}
            self._commit(self._items + [new])
            return dict(new)

    def update(self, expense_id: int, data) -> dict:
        clean = clean_expense(data, categories=self.category_names())
        with self._lock:
            self._refresh()
            if not any(i["id"] == expense_id for i in self._items):
                raise NotFoundError(f"Expense {expense_id} was not found.")
            updated = {"id": expense_id, **clean}
            self._commit([updated if i["id"] == expense_id else i for i in self._items])
            return dict(updated)

    def delete(self, expense_id: int) -> None:
        with self._lock:
            self._refresh()
            if not any(i["id"] == expense_id for i in self._items):
                raise NotFoundError(f"Expense {expense_id} was not found.")
            self._commit([i for i in self._items if i["id"] != expense_id])

    def clear(self) -> int:
        with self._lock:
            self._refresh()
            n = len(self._items)
            self._commit([])
            return n

    def replace_all(self, items: list) -> int:
        with self._lock:
            self._commit([dict(i) for i in items])
            return len(items)
