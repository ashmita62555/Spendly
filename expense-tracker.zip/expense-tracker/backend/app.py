"""Spendly backend: Flask REST API + static frontend.

Run:  python app.py      then open http://127.0.0.1:5000
"""
from __future__ import annotations

import io
import logging
import math
import os
import re
from datetime import date
from pathlib import Path

import pandas as pd
from flask import Flask, Response, g, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

import analytics
import charts
from config_store import CURRENCIES, ConfigStore
from expense_manager import ExpenseManager, NotFoundError, StorageError, ValidationError
from sample_data import sample_expenses

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"
DEFAULT_DATA_FILE = BASE_DIR / "data" / "expenses.json"
DEFAULT_CHARTS_DIR = BASE_DIR.parent / "charts"
ALLOWED_ORIGIN = re.compile(r"^(null|https?://(localhost|127\.0\.0\.1)(:\d+)?)$")

log = logging.getLogger("spendly")


class ApiError(Exception):
    def __init__(self, message, status=400, fields=None):
        super().__init__(message)
        self.message, self.status, self.fields = message, status, fields or {}


def build_manager(json_path=None):
    """Pick the storage backend from environment variables.

    STORAGE=mongo (default) | json      MONGODB_URI, MONGODB_DB, MONGODB_COLLECTION
    If MongoDB is selected but not reachable, fall back to the JSON file and say so.
    """
    json_path = json_path or DEFAULT_DATA_FILE
    note = None
    if os.environ.get("STORAGE", "mongo").lower() == "mongo":
        uri = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
        try:
            from pymongo import MongoClient
            from mongo_manager import MongoExpenseManager

            client = MongoClient(uri, serverSelectionTimeoutMS=3000)
            client.admin.command("ping")
            collection = client[os.environ.get("MONGODB_DB", "spendly")][os.environ.get("MONGODB_COLLECTION", "expenses")]
            return MongoExpenseManager(collection, seed_factory=sample_expenses, import_path=json_path, uri=uri), None
        except Exception as exc:
            log.warning("MongoDB is not available (%s). Using the JSON file instead.", exc)
            note = "MongoDB is not reachable, so a local JSON file is being used instead."
    return ExpenseManager(json_path, seed_factory=sample_expenses), note


def create_app(data_file=None, charts_dir=None, manager=None):
    """data_file -> force JSON storage at that path; manager -> use a ready-made storage object; neither -> read the environment."""
    app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
    note = None
    if manager is None:
        if data_file:
            manager = ExpenseManager(data_file, seed_factory=sample_expenses)
        else:
            manager, note = build_manager()
    storage_info = {**manager.describe(), "note": note}
    charts_path = Path(charts_dir or DEFAULT_CHARTS_DIR)
    app.extensions["expense_manager"] = manager
    app.extensions["storage"] = storage_info
    config = ConfigStore(manager.config_backend())  # settings, currency and categories live in the same database
    manager.category_names = config.names
    app.extensions["config"] = config

    def context():
        if "ctx" not in g:
            g.ctx = config.context()
        return g.ctx

    # ---------- helpers ----------
    def body():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ApiError("Request body must be a JSON object.")
        return data

    def parse_float(args, name):
        raw = args.get(name, "").strip()
        if not raw:
            return None
        try:
            v = float(raw)
        except ValueError:
            raise ApiError(f"'{name}' must be a number.")
        if not math.isfinite(v):
            raise ApiError(f"'{name}' must be a number.")
        return v

    def parse_day(args, name):
        raw = args.get(name, "").strip()
        if not raw:
            return None
        try:
            return pd.Timestamp(date.fromisoformat(raw)).strftime("%Y-%m-%d")
        except ValueError:
            raise ApiError(f"'{name}' must be a date in YYYY-MM-DD format.")

    def parse_month(name):
        raw = request.args.get(name, "").strip()
        if raw and not analytics.MONTH_RE.fullmatch(raw):
            raise ApiError(f"'{name}' must be a month in YYYY-MM format.")
        return raw or None

    def parse_int(name, default, lo, hi):
        raw = request.args.get(name, "").strip()
        if not raw:
            return default
        try:
            return max(lo, min(hi, int(raw)))
        except ValueError:
            raise ApiError(f"'{name}' must be a whole number.")

    def parse_filters():
        a = request.args
        f = {"q": a.get("q", "")[:100], "min": parse_float(a, "min"), "max": parse_float(a, "max"),
             "from": parse_day(a, "from"), "to": parse_day(a, "to")}
        cat = a.get("category", "").strip()
        if cat and cat.lower() != "all":
            match = next((c for c in context()["names"] if c.lower() == cat.lower()), None)
            if not match:
                raise ApiError("Unknown category.")
            f["category"] = match
        f["range"] = a.get("range", "all") or "all"
        if f["range"] not in analytics.RANGES:
            raise ApiError("Unknown date range.")
        f["sort"] = a.get("sort", "date-desc") or "date-desc"
        if f["sort"] not in analytics.SORTS:
            raise ApiError("Unknown sort option.")
        return f

    def frame():
        return analytics.to_df(manager.all())

    # ---------- expenses ----------
    @app.get("/api/health")
    def health():
        try:
            return jsonify({"status": "ok", "expenses": len(manager.all()), "storage": storage_info})
        except StorageError as exc:
            return jsonify({"status": "error", "error": str(exc), "storage": storage_info}), 503

    @app.get("/api/expenses")
    def list_expenses():
        per_page, filters = parse_int("per_page", 10, 1, 100), parse_filters()
        df = frame()
        out = analytics.apply_filters(df, filters, date.today())
        pages = max(1, math.ceil(len(out) / per_page))
        page = min(parse_int("page", 1, 1, 10**6), pages)
        return jsonify({"items": analytics.records(out.iloc[(page - 1) * per_page: page * per_page]),
                        "count": int(len(out)), "sum": analytics._num(out["amount"].sum()),
                        "page": page, "pages": pages, "per_page": per_page, "overall_count": int(len(df))})

    @app.post("/api/expenses")
    def add_expense():
        return jsonify({"expense": manager.add(body()), "message": "Expense added successfully."}), 201

    @app.get("/api/expenses/<int:expense_id>")
    def get_expense(expense_id):
        return jsonify({"expense": manager.get(expense_id)})

    @app.put("/api/expenses/<int:expense_id>")
    def update_expense(expense_id):
        return jsonify({"expense": manager.update(expense_id, body()), "message": "Expense updated successfully."})

    @app.delete("/api/expenses/<int:expense_id>")
    def delete_expense(expense_id):
        manager.delete(expense_id)
        return jsonify({"id": expense_id, "message": "Expense deleted successfully."})

    @app.delete("/api/expenses")
    def clear_expenses():
        if request.args.get("confirm") != "true":
            raise ApiError("Add ?confirm=true to delete every expense.")
        return jsonify({"deleted": manager.clear(), "message": "All expenses deleted."})

    @app.post("/api/expenses/sample")
    def load_sample():
        names = context()["names"]  # sample expenses use the default categories; map any you removed onto one you still have
        items = [{**i, "category": i["category"] if i["category"] in names else names[0]} for i in sample_expenses()]
        return jsonify({"loaded": manager.replace_all(items), "message": "Sample data loaded."})

    # ---------- analytics ----------
    @app.get("/api/analytics/summary")
    def analytics_summary():
        return jsonify(analytics.summary(frame(), date.today(), context()))

    @app.get("/api/analytics/categories")
    def analytics_categories():
        return jsonify(analytics.categories(frame(), context()["names"], parse_month("month")))

    @app.get("/api/analytics/monthly")
    def analytics_monthly():
        return jsonify({"months": analytics.monthly(frame(), parse_int("months", 6, 1, 24), date.today())})

    @app.get("/api/analytics/report")
    def analytics_report():
        return jsonify(analytics.report(frame(), parse_month("month"), parse_month("compare"), date.today(), context()["names"]))

    @app.get("/api/analytics/charts")
    def analytics_charts():
        theme = request.args.get("theme", "light")
        if theme not in charts.THEMES:
            raise ApiError("Theme must be 'light' or 'dark'.")
        size = request.args.get("size", "wide")
        if size not in charts.SIZES:
            raise ApiError("Size must be 'wide' or 'compact'.")
        df = frame()
        ctx = context()
        made = charts.generate_all(df, theme, charts_path, max(manager.mtime_ns, config.mtime_ns), size, ctx)
        return jsonify({"theme": theme, "charts": [
            {"id": c["id"], "title": c["title"], "url": f"/charts/{c['filename']}?v={c['mtime_ns']}"} for c in made]})

    @app.get("/charts/<path:filename>")
    def serve_chart(filename):
        resp = send_from_directory(charts_path, filename)
        resp.headers["Cache-Control"] = "public, max-age=3600"
        return resp

    # ---------- configuration: settings, currency, categories ----------
    def config_payload():
        c = context()
        return {"settings": c["settings"], "categories": c["categories"], "currency": c["currency"],
                "currencies": [{"code": k, "symbol": v["symbol"], "name": v["name"]} for k, v in CURRENCIES.items()],
                "storage": storage_info}

    def find_category(name):
        key = str(name).strip().lower()
        for n in context()["names"]:
            if n.lower() == key:
                return n
        raise NotFoundError(f"Category '{name}' was not found.")

    @app.get("/api/config")
    def get_config():
        return jsonify(config_payload())

    @app.put("/api/settings")
    def put_settings():
        config.update_settings(body())
        g.pop("ctx", None)
        return jsonify({**config_payload(), "message": "Settings saved."})

    @app.get("/api/categories")
    def list_categories():
        counts = frame()["category"].value_counts()
        return jsonify({"categories": [{**c, "count": int(counts.get(c["name"], 0))} for c in context()["categories"]]})

    @app.post("/api/categories")
    def add_category():
        item = config.add_category(body())
        return jsonify({"category": item, "message": "Category added."}), 201

    @app.put("/api/categories/<name>")
    def update_category(name):
        old, item = config.update_category(find_category(name), body())
        if old != item["name"]:  # renamed: move its expenses across so nothing is lost
            try:
                manager.rename_category(old, item["name"])
            except Exception:
                config.update_category(item["name"], {"name": old})  # undo the rename
                raise
        return jsonify({"category": item, "message": "Category updated."})

    @app.delete("/api/categories/<name>")
    def delete_category(name):
        match = find_category(name)
        count = int((frame()["category"] == match).sum())
        if count:  # expenses in this category must go somewhere
            target = request.args.get("reassign_to", "").strip().lower()
            dest = next((n for n in context()["names"] if n.lower() == target and n != match), None)
            if not dest:
                raise ApiError(f"Choose a category to move the {count} expense{'s' if count != 1 else ''} to.", fields={"reassign_to": "required"})
            manager.rename_category(match, dest)
        config.delete_category(match)
        return jsonify({"name": match, "moved": count, "message": "Category deleted."})

    # ---------- export ----------
    @app.get("/api/export")
    def export():
        fmt = request.args.get("format", "csv")
        if fmt not in ("csv", "json"):
            raise ApiError("Format must be 'csv' or 'json'.")
        out = analytics.apply_filters(frame(), parse_filters(), date.today())
        rows = analytics.records(out)
        if fmt == "json":
            resp = jsonify(rows)
        else:
            safe = out.assign(description=out["description"].map(lambda s: "'" + s if s[:1] in "=+-@" else s))
            buf = io.StringIO()
            safe[["id", "date", "category", "amount", "description"]].assign(date=lambda d: d["date"].dt.strftime("%Y-%m-%d")).to_csv(buf, index=False)
            resp = Response(buf.getvalue(), mimetype="text/csv")
        resp.headers["Content-Disposition"] = f"attachment; filename=expenses.{fmt}"
        return resp

    # ---------- frontend + errors ----------
    @app.get("/")
    def index():
        return send_from_directory(FRONTEND_DIR, "index.html")

    @app.errorhandler(ApiError)
    def on_api_error(e):
        return jsonify({"error": e.message, "fields": e.fields}), e.status

    @app.errorhandler(ValidationError)
    def on_validation(e):
        return jsonify({"error": next(iter(e.fields.values())), "fields": e.fields}), 400

    @app.errorhandler(NotFoundError)
    def on_missing(e):
        return jsonify({"error": str(e)}), 404

    @app.errorhandler(StorageError)
    def on_storage(e):
        return jsonify({"error": str(e)}), 500

    @app.errorhandler(HTTPException)
    def on_http(e):
        if request.path.startswith("/api/"):
            msg = {404: "That resource was not found.", 405: "That method is not allowed here.", 413: "The request is too large."}.get(e.code, e.description)
            return jsonify({"error": msg}), e.code
        return e

    @app.errorhandler(Exception)
    def on_crash(e):
        log.exception("Unhandled error on %s %s", request.method, request.path)  # stack trace stays in the server log
        return jsonify({"error": "Something went wrong on the server. Please try again."}), 500

    @app.after_request
    def headers(resp):
        origin = request.headers.get("Origin", "")
        if ALLOWED_ORIGIN.match(origin):  # lets the page work when opened straight from the file system
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
            resp.headers["Vary"] = "Origin"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    return app


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    _app = create_app()
    _s = _app.extensions["storage"]
    _where = f"MongoDB → {_s['database']}.{_s['collection']} ({_s['uri']})" if _s["type"] == "mongodb" else f"JSON file → {_s['path']}"
    print(f"\n  Spendly is running → http://127.0.0.1:5000\n  Storage: {_where}")
    if _s.get("note"):
        print(f"  Note: {_s['note']}")
    print()
    _app.run(host="127.0.0.1", port=5000, debug=os.environ.get("EXPENSE_DEBUG") == "1")
