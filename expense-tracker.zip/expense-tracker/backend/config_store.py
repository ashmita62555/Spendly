"""App configuration kept in the database next to the expenses: profile settings, currency and the category list.

MongoDB: one document in the `config` collection (_id "app").   JSON mode: backend/data/config.json.
Everything read from storage is re-validated, so a hand edit in Compass can never crash the app.
"""
from __future__ import annotations

import copy
import json
import logging
import os
import re
import tempfile
import threading
import time
from pathlib import Path

from expense_manager import NotFoundError, StorageError, ValidationError

log = logging.getLogger("expenses.config")

DEFAULT_CATEGORIES = [
    {"name": "Food", "emoji": "🍔", "color": "#f59e0b"},
    {"name": "Travel", "emoji": "🚗", "color": "#0ea5e9"},
    {"name": "Education", "emoji": "📚", "color": "#6366f1"},
    {"name": "Shopping", "emoji": "🛍", "color": "#ec4899"},
    {"name": "Entertainment", "emoji": "🎬", "color": "#8b5cf6"},
    {"name": "Bills", "emoji": "🏠", "color": "#14b8a6"},
    {"name": "Health", "emoji": "💊", "color": "#ef4444"},
    {"name": "Other", "emoji": "📦", "color": "#64748b"},
]
CURRENCIES = {
    "INR": {"symbol": "₹", "locale": "en-IN", "name": "Indian Rupee"},
    "USD": {"symbol": "$", "locale": "en-US", "name": "US Dollar"},
    "EUR": {"symbol": "€", "locale": "en-IE", "name": "Euro"},
    "GBP": {"symbol": "£", "locale": "en-GB", "name": "British Pound"},
    "JPY": {"symbol": "¥", "locale": "ja-JP", "name": "Japanese Yen"},
}
DEFAULT_SETTINGS = {"app_name": "Spendly", "display_name": "Subham", "tagline": "Personal plan",
                    "currency": "INR", "theme": "light", "sidebar_collapsed": False}
MAX_CATEGORIES = 24
DEFAULT_EMOJI, DEFAULT_COLOR = "🏷️", "#6366f1"
_NAME_RE = re.compile(r"[\w][\w &'\-]{0,19}")
_COLOR_RE = re.compile(r"#[0-9a-fA-F]{6}")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]+")
_TEXT_LIMITS = {"app_name": ("App name", 24), "display_name": ("Display name", 30), "tagline": ("Tagline", 30)}


def _tidy(value) -> str:
    return " ".join(_CONTROL_RE.sub(" ", value).split()) if isinstance(value, str) else ""


def currency_info(code: str) -> dict:
    return {"code": code, **CURRENCIES.get(code, CURRENCIES["INR"])}


def clean_settings(patch: dict) -> dict:
    """Validate the settings keys present in `patch` (unknown keys are ignored)."""
    errors, out = {}, {}
    for key, (label, limit) in _TEXT_LIMITS.items():
        if key in patch:
            v = _tidy(patch[key])
            if not v:
                errors[key] = f"{label} can't be empty."
            elif len(v) > limit:
                errors[key] = f"{label} must be {limit} characters or fewer."
            else:
                out[key] = v
    if "currency" in patch:
        if patch["currency"] in CURRENCIES:
            out["currency"] = patch["currency"]
        else:
            errors["currency"] = "Please choose a supported currency."
    if "theme" in patch:
        if patch["theme"] in ("light", "dark"):
            out["theme"] = patch["theme"]
        else:
            errors["theme"] = "Theme must be light or dark."
    if "sidebar_collapsed" in patch:
        if isinstance(patch["sidebar_collapsed"], bool):
            out["sidebar_collapsed"] = patch["sidebar_collapsed"]
        else:
            errors["sidebar_collapsed"] = "Must be true or false."
    if errors:
        raise ValidationError(errors)
    return out


def clean_category(data: dict, taken: set, base: dict | None = None) -> dict:
    """Validate a category. `taken` holds the lower-cased names of the OTHER categories; `base` is the current value for partial updates."""
    errors, out = {}, dict(base or {})
    if not isinstance(data, dict):
        raise ValidationError({"_": "Request body must be a JSON object."})
    if "name" in data or base is None:
        n = _tidy(data.get("name"))
        if not n:
            errors["name"] = "Please enter a category name."
        elif not _NAME_RE.fullmatch(n):
            errors["name"] = "Use up to 20 letters, numbers, spaces, & or -."
        elif n.lower() in taken:
            errors["name"] = "A category with this name already exists."
        else:
            out["name"] = n
    if "emoji" in data or base is None:
        e = _tidy(data.get("emoji")).replace(" ", "")
        if not e:
            out["emoji"] = DEFAULT_EMOJI
        elif len(e) > 8 or re.search(r"[A-Za-z0-9<>&\"']", e):
            errors["emoji"] = "Please use a single emoji or symbol."
        else:
            out["emoji"] = e
    if "color" in data or base is None:
        c = data.get("color", DEFAULT_COLOR)
        if isinstance(c, str) and _COLOR_RE.fullmatch(c.strip()):
            out["color"] = c.strip().lower()
        else:
            errors["color"] = "Please pick a valid color."
    if errors:
        raise ValidationError(errors)
    return out


# ---------- storage backends ----------
class JsonConfigBackend:
    def __init__(self, path):
        self.path = Path(path)

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else None
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as exc:
            log.warning("Unreadable %s (%s). Using defaults.", self.path, exc)
            return None

    def save(self, data):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".config-", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                os.replace(tmp, self.path)
            except BaseException:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
        except OSError as exc:
            raise StorageError("Unable to save your settings.") from exc


class MongoConfigBackend:
    def __init__(self, collection):
        self._col = collection

    def load(self):
        from pymongo.errors import PyMongoError
        try:
            doc = self._col.find_one({"_id": "app"})
        except PyMongoError as exc:
            raise StorageError("Unable to reach the database. Is MongoDB running?") from exc
        if not doc:
            return None
        doc.pop("_id", None)
        return doc

    def save(self, data):
        from pymongo.errors import PyMongoError
        try:
            self._col.replace_one({"_id": "app"}, {"_id": "app", **data}, upsert=True)
        except PyMongoError as exc:
            raise StorageError("Unable to reach the database. Is MongoDB running?") from exc


# ---------- the store ----------
class ConfigStore:
    def __init__(self, backend):
        self._b = backend
        self._lock = threading.RLock()
        self._fp = None
        self._version_ns = time.time_ns()
        with self._lock:
            if self._b.load() is None:
                self._save(self._normalise(None))

    @property
    def mtime_ns(self) -> int:
        """Changes whenever the configuration changes (used to refresh cached chart images)."""
        return self._version_ns

    @staticmethod
    def _normalise(raw) -> dict:
        raw = raw if isinstance(raw, dict) else {}
        settings = dict(DEFAULT_SETTINGS)
        stored = raw.get("settings") if isinstance(raw.get("settings"), dict) else {}
        for key in DEFAULT_SETTINGS:
            if key in stored:
                try:
                    settings.update(clean_settings({key: stored[key]}))
                except ValidationError:
                    log.warning("Ignoring invalid setting %s", key)
        cats, seen = [], set()
        for c in raw.get("categories") or []:
            try:
                item = clean_category(c, seen)
            except ValidationError:
                log.warning("Ignoring invalid category %r", c)
                continue
            seen.add(item["name"].lower())
            cats.append(item)
        return {"settings": settings, "categories": cats[:MAX_CATEGORIES] or copy.deepcopy(DEFAULT_CATEGORIES)}

    def _save(self, cfg):
        self._b.save(cfg)
        self._fp = json.dumps(cfg, sort_keys=True)
        self._version_ns = time.time_ns()

    def get(self) -> dict:
        with self._lock:
            cfg = self._normalise(self._b.load())
            fp = json.dumps(cfg, sort_keys=True)
            if fp != self._fp:  # first read, or edited by hand in Compass / the file
                self._fp, self._version_ns = fp, time.time_ns()
            return cfg

    def context(self) -> dict:
        cfg = self.get()
        cats = cfg["categories"]
        return {"settings": cfg["settings"], "categories": cats, "names": [c["name"] for c in cats],
                "emoji": {c["name"]: c["emoji"] for c in cats}, "colors": {c["name"]: c["color"] for c in cats},
                "currency": currency_info(cfg["settings"]["currency"])}

    def names(self) -> list:
        return [c["name"] for c in self.get()["categories"]]

    # ---- changes ----
    def update_settings(self, patch) -> dict:
        if not isinstance(patch, dict):
            raise ValidationError({"_": "Request body must be a JSON object."})
        changes = clean_settings(patch)
        with self._lock:
            cfg = self._normalise(self._b.load())
            cfg["settings"].update(changes)
            self._save(cfg)
            return cfg["settings"]

    @staticmethod
    def _find(cfg, name):
        key = str(name).strip().lower()
        for i, c in enumerate(cfg["categories"]):
            if c["name"].lower() == key:
                return i
        raise NotFoundError(f"Category '{name}' was not found.")

    def add_category(self, data) -> dict:
        with self._lock:
            cfg = self._normalise(self._b.load())
            if len(cfg["categories"]) >= MAX_CATEGORIES:
                raise ValidationError({"name": f"You can have up to {MAX_CATEGORIES} categories."})
            item = clean_category(data, {c["name"].lower() for c in cfg["categories"]})
            cfg["categories"].append(item)
            self._save(cfg)
            return item

    def update_category(self, name, data):
        """Returns (old_name, updated_category)."""
        with self._lock:
            cfg = self._normalise(self._b.load())
            i = self._find(cfg, name)
            old = cfg["categories"][i]
            item = clean_category(data, {c["name"].lower() for j, c in enumerate(cfg["categories"]) if j != i}, base=old)
            cfg["categories"][i] = item
            self._save(cfg)
            return old["name"], item

    def delete_category(self, name) -> str:
        with self._lock:
            cfg = self._normalise(self._b.load())
            i = self._find(cfg, name)
            if len(cfg["categories"]) <= 1:
                raise ValidationError({"name": "You need at least one category."})
            removed = cfg["categories"].pop(i)
            self._save(cfg)
            return removed["name"]
