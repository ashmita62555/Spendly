"""Realistic demo expenses, generated relative to today so the dashboard always looks current."""
import random
from datetime import date, timedelta

_ITEMS = {
    "Food": [("Lunch with friends", 120, 520), ("Groceries", 400, 1800), ("Tea & snacks", 30, 90), ("Dinner out", 350, 1100), ("Breakfast", 60, 160)],
    "Travel": [("Bus pass", 60, 400), ("Auto ride", 40, 180), ("Train ticket", 150, 900), ("Fuel", 500, 1500)],
    "Education": [("Online course", 400, 2400), ("Books", 250, 1200), ("Exam fee", 500, 1500)],
    "Shopping": [("Shoes", 1200, 3500), ("T-shirt", 400, 1200), ("Headphones", 900, 3200), ("Backpack", 700, 1800)],
    "Entertainment": [("Movie tickets", 250, 700), ("OTT subscription", 149, 499), ("Gaming top-up", 100, 600)],
    "Bills": [("Electricity bill", 600, 1900), ("Mobile recharge", 239, 599), ("Internet bill", 499, 999)],
    "Health": [("Pharmacy", 80, 600), ("Doctor visit", 300, 900), ("Gym membership", 500, 1500)],
    "Other": [("Gift", 200, 1500), ("Stationery", 50, 300), ("Donation", 100, 500)],
}
_WEIGHTS = {"Food": 5, "Travel": 3, "Bills": 3, "Shopping": 2, "Entertainment": 2, "Education": 1, "Health": 1, "Other": 1}


def sample_expenses(today=None, count=85, seed=20261005):
    today = today or date.today()
    rng = random.Random(seed)
    pool = [c for c, w in _WEIGHTS.items() for _ in range(w)]
    rows = []
    for i in range(count):
        cat = rng.choice(pool)
        desc, lo, hi = rng.choice(_ITEMS[cat])
        offset = i if i < 6 else int(rng.random() ** 1.1 * 150)  # first few are very recent
        amount = max(5, round((lo + rng.random() * (hi - lo)) / 5) * 5)
        rows.append({"date": (today - timedelta(days=offset)).isoformat(), "category": cat, "amount": amount, "description": desc})
    rows.sort(key=lambda r: r["date"])
    return [{"id": n, **r} for n, r in enumerate(rows, start=1)]
