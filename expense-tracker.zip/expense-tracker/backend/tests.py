import json, os, sys, tempfile
from datetime import date, timedelta
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
CUR = date.today().strftime("%Y-%m")
PREV = (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
from app import create_app

tmp = tempfile.mkdtemp()
data_file = os.path.join(tmp, "expenses.json")
app = create_app(data_file, os.path.join(tmp, "charts"))
c = app.test_client()
ok = fail = 0
def check(name, cond, extra=""):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print("FAIL:", name, extra)

r = c.get("/api/health"); check("health", r.status_code == 200 and r.json["expenses"] > 50)
r = c.get("/api/expenses?per_page=5"); j = r.json
check("list", r.status_code == 200 and len(j["items"]) == 5 and j["pages"] > 1, j)
# filters/sort/search
r = c.get("/api/expenses?category=Food&sort=amt-desc&per_page=100").json
check("cat filter", all(i["category"] == "Food" for i in r["items"]))
check("sort desc", [i["amount"] for i in r["items"]] == sorted([i["amount"] for i in r["items"]], reverse=True))
r = c.get("/api/expenses?q=lunch&per_page=100").json
check("search", r["count"] > 0 and all("lunch" in i["description"].lower() for i in r["items"]))
r = c.get("/api/expenses?min=1000&max=2000&per_page=100").json
check("amount range", all(1000 <= i["amount"] <= 2000 for i in r["items"]))
r = c.get("/api/expenses?range=month&per_page=100").json
check("this month", r["count"] > 0)
r = c.get("/api/expenses?sort=az&per_page=100").json["items"]
check("az sort", [i["description"].lower() for i in r] == sorted(i["description"].lower() for i in r))
for bad in ["sort=nope", "category=Zzz", "range=yesterday", "min=abc", "from=2026-13-40", "page=x", "per_page=-"]:
    check("bad query " + bad, c.get("/api/expenses?" + bad).status_code == 400, bad)
# CRUD
r = c.post("/api/expenses", json={"date": "2026-10-05", "category": "Food", "amount": "450", "description": "  Test   lunch "})
check("create", r.status_code == 201 and r.json["expense"]["description"] == "Test lunch" and r.json["expense"]["amount"] == 450, r.json)
eid = r.json["expense"]["id"]
check("get", c.get(f"/api/expenses/{eid}").json["expense"]["id"] == eid)
r = c.put(f"/api/expenses/{eid}", json={"date": "2026-10-04", "category": "travel", "amount": 99.5, "description": "Bus"})
check("update", r.status_code == 200 and r.json["expense"]["category"] == "Travel" and r.json["expense"]["amount"] == 99.5, r.json)
check("persisted", any(i["id"] == eid and i["description"] == "Bus" for i in json.load(open(data_file))))
r = c.delete(f"/api/expenses/{eid}"); check("delete", r.status_code == 200)
check("delete again 404", c.delete(f"/api/expenses/{eid}").status_code == 404)
check("get missing 404", c.get("/api/expenses/999999").status_code == 404)
check("put missing 404", c.put("/api/expenses/999999", json={"date": "2026-10-04", "category": "Food", "amount": 5, "description": "x"}).status_code == 404)
check("invalid id string", c.get("/api/expenses/abc").status_code == 404 and c.get("/api/expenses/abc").is_json)
check("negative id", c.delete("/api/expenses/-1").status_code in (404, 405))
# invalid inputs
good = {"date": "2026-10-05", "category": "Food", "amount": 10, "description": "ok"}
bads = {"amount": ["abc", -500, 0, "₹₹500", "-5", "1e3", True, None, float("inf"), 10**9, "5.555", [1]], "date": ["2026-02-31", "05-10-2026", "2999-01-01", "", None, "1999-01-01", 20261005],
        "category": ["", "Nope", None, 5], "description": ["", "   ", None, "x" * 81, 12]}
for field, vals in bads.items():
    for v in vals:
        payload = {**good, field: v}
        try:
            r = c.post("/api/expenses", data=json.dumps(payload), content_type="application/json")
        except Exception as e:
            check(f"bad {field}={v!r}", False, e); continue
        check(f"bad {field}={v!r}", r.status_code == 400 and field in r.json["fields"], (r.status_code, r.json))
for raw in ["not json", "[1,2]", "null", ""]:
    check("bad body " + raw, c.post("/api/expenses", data=raw, content_type="application/json").status_code == 400)
check("no content-type", c.post("/api/expenses", data=json.dumps(good)).status_code == 400)
check("too large", c.post("/api/expenses", data="x" * 70000, content_type="application/json").status_code == 413)
check("method not allowed", c.patch("/api/expenses").status_code == 405)
check("clear needs confirm", c.delete("/api/expenses").status_code == 400)
r = c.post("/api/expenses", json={**good, "description": "<script>alert(1)</script>\x00\x07"}); check("html kept as text, ctrl stripped", r.status_code == 201 and "\x00" not in r.json["expense"]["description"])
# analytics
s = c.get("/api/analytics/summary").json
check("summary", s["count"] > 50 and s["highest"]["amount"] >= s["lowest"]["amount"] and s["insights"] and s["this_month"]["count"] > 0, s)
cat = c.get("/api/analytics/categories").json
check("categories", len(cat["categories"]) == 8 and abs(sum(x["share"] for x in cat["categories"]) - 100) < 0.5)
check("categories month", c.get(f"/api/analytics/categories?month={PREV}").status_code == 200 and c.get("/api/analytics/categories?month=bad").status_code == 400)
m = c.get("/api/analytics/monthly?months=6").json["months"]; check("monthly", len(m) == 6 and m[-1]["month"] == CUR, m[-1])
rp = c.get("/api/analytics/report").json; check("report", rp["month"]["key"] == CUR and rp["compare"]["key"] == PREV and len(rp["months"]) >= 2, rp["month"]["key"])
rp = c.get(f"/api/analytics/report?month={PREV}&compare={CUR}").json; check("report explicit", rp["month"]["key"] == PREV)
ch = c.get("/api/analytics/charts?theme=dark").json; check("charts json", len(ch["charts"]) == 4, ch)
for item in ch["charts"]:
    r = c.get(item["url"]); check("png " + item["id"], r.status_code == 200 and r.data[:4] == b"\x89PNG" and len(r.data) > 5000, len(r.data))
check("charts bad theme", c.get("/api/analytics/charts?theme=neon").status_code == 400)
check("chart traversal", c.get("/charts/..%2Fapp.py").status_code == 404)
# export
r = c.get("/api/export?format=csv&category=Food"); check("csv", r.status_code == 200 and r.data.startswith(b"id,date,category,amount,description") and "attachment" in r.headers["Content-Disposition"])
check("json export", isinstance(c.get("/api/export?format=json").json, list))
check("bad export", c.get("/api/export?format=xml").status_code == 400)
# CORS
r = c.get("/api/health", headers={"Origin": "null"}); check("cors null", r.headers.get("Access-Control-Allow-Origin") == "null")
r = c.get("/api/health", headers={"Origin": "https://evil.example"}); check("cors blocked", "Access-Control-Allow-Origin" not in r.headers)
# frontend served
check("index", c.get("/").status_code == 200 and c.get("/css/style.css").status_code == 200 and c.get("/js/app.js").status_code == 200)
# empty data
check("clear", c.delete("/api/expenses?confirm=true").json["deleted"] > 0)
check("empty list", c.get("/api/expenses").json["count"] == 0)
s = c.get("/api/analytics/summary").json; check("empty summary", s["count"] == 0 and s["highest"] is None and s["insights"], s)
check("empty cats", c.get("/api/analytics/categories").json["total"] == 0)
check("empty monthly", len(c.get("/api/analytics/monthly").json["months"]) == 6)
check("empty report", c.get("/api/analytics/report").status_code == 200)
check("empty charts", c.get("/api/analytics/charts?theme=light").status_code == 200)
check("empty export", c.get("/api/export?format=csv").status_code == 200)
check("sample", c.post("/api/expenses/sample").json["loaded"] > 50)
# corrupted / missing / hand-edited file
open(data_file, "w").write("{ this is not json")
r = c.get("/api/expenses"); check("corrupt recovered", r.status_code == 200 and r.json["count"] == 0)
check("corrupt backup made", any("corrupt" in f for f in os.listdir(tmp)))
os.remove(data_file)
from expense_manager import ExpenseManager
m2 = ExpenseManager(data_file); check("missing file created", os.path.exists(data_file) and m2.all() == [])
json.dump([{"id": 1, "date": "2026-01-01", "category": "Food", "amount": 5, "description": "ok"}, {"id": 1, "date": "bad"}, {"nope": 1}, "x"], open(data_file, "w"))
check("bad records skipped", [i["id"] for i in m2.all()] == [1])
print(f"\n{ok} passed, {fail} failed")
sys.exit(1 if fail else 0)
