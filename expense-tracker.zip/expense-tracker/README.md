# Spendly — Personal Expense Tracker & Analysis System

A personal finance dashboard. Add, edit, search and analyse your expenses.

**Stack:** HTML5 · CSS3 · vanilla JavaScript · Python 3 · Flask · Pandas · Matplotlib · MongoDB (with a JSON-file fallback)

## Features

- Dashboard with animated summary cards, spending trend, category split, recent expenses and insights calculated from your data
- Add, edit and delete expenses (with confirmation), validated in the browser and again on the server
- Search (description, category, date, amount), filters (date range, category, amount range), 7 sort options, pagination
- Analytics: total, average, highest, lowest, most expensive and most frequent category, daily / monthly / per-category averages
- Reports: monthly report, month-to-month comparison, and four Matplotlib charts (bar, pie, line, histogram) in light and dark themes
- MongoDB storage: browse and edit your data in MongoDB Compass
- Everything is configurable and stored in the database (no fixed values): categories (add, rename, recolor, delete), currency, display name, tagline, app name, theme and sidebar state
- CSV / JSON export, dark mode, keyboard accessible
- Fully responsive: collapsible sidebar on desktop, drawer + bottom navigation on phones and tablets, tables that turn into cards, bottom-sheet dialogs, and charts re-drawn at a phone-friendly size

## How it fits together

```
Browser (frontend/)  →  Flask REST API (backend/app.py)  →  MongoDB  (or data/expenses.json)
                                  ↓
                  Pandas analysis (analytics.py)  →  Matplotlib PNGs (charts.py → charts/)
```

## Folder structure

```
expense-tracker/
├── frontend/
│   ├── index.html
│   ├── css/style.css          # theme colours are CSS variables at the top
│   └── js/app.js
├── backend/
│   ├── app.py                 # Flask app + REST endpoints
│   ├── expense_manager.py     # validation + JSON-file storage
│   ├── mongo_manager.py       # MongoDB storage (same interface)
│   ├── config_store.py        # settings, currency and categories (stored in the database)
│   ├── analytics.py           # Pandas calculations
│   ├── charts.py              # Matplotlib chart generation
│   ├── sample_data.py         # demo data used on first run
│   ├── tests.py               # API + JSON storage tests
│   ├── tests_mongo.py         # MongoDB storage tests (uses mongomock)
│   ├── tests_config.py        # settings + categories tests (JSON and MongoDB)
│   └── data/expenses.json     # only used in JSON mode
├── charts/                    # generated PNG charts
├── requirements.txt
├── requirements-dev.txt       # adds mongomock for the tests
└── README.md
```

## Installation

You need **Python 3.11 or newer** (Pandas 3 requires it).

```bash
cd expense-tracker

# 1. create a virtual environment
python -m venv .venv

# 2. activate it
#    Windows (PowerShell):  .venv\Scripts\Activate.ps1
#    Windows (cmd):         .venv\Scripts\activate.bat
#    macOS / Linux:         source .venv/bin/activate

# 3. install the packages
pip install -r requirements.txt
```

Required packages: Flask, pandas, matplotlib (NumPy is installed automatically).

## MongoDB and Compass

By default the app stores expenses in **MongoDB** on your own computer.

1. Install **MongoDB Community Server** and **MongoDB Compass** from mongodb.com/try/download.
   - Windows: the installer sets MongoDB up as a service that starts automatically.
   - macOS: `brew tap mongodb/brew && brew install mongodb-community && brew services start mongodb-community`
   - Linux: `sudo systemctl start mongod`
   - Docker: `docker run -d --name mongo -p 27017:27017 mongo:7`
2. Start the app (next section). On first run it creates the database `spendly` with the collection `expenses` and fills it with sample data. If you used the JSON version before, your old `backend/data/expenses.json` is imported instead.
3. Open **Compass**, click **Connect** with `mongodb://localhost:27017`, then open **spendly → expenses**. You will see the same expenses as in the app.

You can add, edit and delete documents in Compass, then reload the app. The app tolerates hand-typed documents: a missing `id` is filled in for you, dates may be real BSON dates, amounts may be Double, Int or Decimal128, and documents with invalid data are skipped (never deleted). Each document looks like this:

```json
{ "_id": "ObjectId(...)", "id": 12, "date": "2026-10-05", "category": "Food", "amount": 450, "description": "Lunch" }
```

The database also has three small helper collections: `counters` (the next numeric id, so ids are never reused), `meta` (remembers that first-run setup is done, so "Delete all" is not undone on restart) and `config` (one document with your settings and category list, which you can also edit in Compass; invalid values are ignored and replaced by defaults).

**Settings** (environment variables, all optional):

| Variable | Default | Meaning |
|---|---|---|
| `STORAGE` | `mongo` | `mongo` or `json` |
| `MONGODB_URI` | `mongodb://localhost:27017` | Any MongoDB connection string, including Atlas (`mongodb+srv://...`) |
| `MONGODB_DB` | `spendly` | Database name |
| `MONGODB_COLLECTION` | `expenses` | Collection name |

Set them before starting the app. PowerShell: `$env:MONGODB_URI="mongodb://localhost:27017"`. macOS/Linux: `export MONGODB_URI=...`.

If MongoDB is not running, the app **falls back to the JSON file** and tells you in the terminal and on the Settings page, so it still works. Start MongoDB and restart the app to switch back; the JSON data is imported the first time MongoDB is used.

## Run it

```bash
cd backend
python app.py
```

The terminal shows which storage is in use. Then open **http://127.0.0.1:5000** in your browser. Flask serves the frontend and the API from the same address.

You can also open `frontend/index.html` straight from your file system. It talks to the backend at `http://127.0.0.1:5000`, so the backend must be running.

On first run the app is filled with sample expenses so the dashboard is not empty. Remove them with **Settings → Delete all expenses**.

## Run the tests

```bash
pip install -r requirements-dev.txt
cd backend
python tests.py          # API + JSON storage
python tests_mongo.py    # MongoDB storage (in-memory fake, no server needed)
python tests_config.py   # settings, currency and categories
```

The tests use temporary data, so your real data is never touched. The MongoDB tests use `mongomock`, an in-memory stand-in for MongoDB.

## API

All responses are JSON. Errors look like `{"error": "Friendly message", "fields": {"amount": "..."}}`.

| Method | Endpoint | What it does |
|---|---|---|
| GET | `/api/expenses` | List expenses. Query: `q`, `category`, `range` (all, today, week, month, custom), `from`, `to`, `min`, `max`, `sort` (date-desc, date-asc, amt-desc, amt-asc, az, za, cat), `page`, `per_page` |
| POST | `/api/expenses` | Add an expense → `201` |
| GET | `/api/expenses/<id>` | Get one expense (`404` if missing) |
| PUT | `/api/expenses/<id>` | Replace an expense |
| DELETE | `/api/expenses/<id>` | Delete an expense |
| DELETE | `/api/expenses?confirm=true` | Delete every expense |
| POST | `/api/expenses/sample` | Replace all data with sample data |
| GET | `/api/analytics/summary` | Totals, averages, highest/lowest, top categories, this month vs last month, insights |
| GET | `/api/analytics/categories?month=YYYY-MM` | Category totals, counts, averages, shares |
| GET | `/api/analytics/monthly?months=6` | Monthly totals |
| GET | `/api/analytics/report?month=YYYY-MM&compare=YYYY-MM` | Monthly report and comparison |
| GET | `/api/analytics/charts?theme=light` or `dark`, `size=wide` or `compact` | Generates the Matplotlib PNGs and returns their URLs (`compact` is for phones) |
| GET | `/api/export?format=csv` or `json` | Download expenses (accepts the same filters as the list) |
| GET | `/api/health` | Health check, including which storage is in use (`503` if the database is down) |

Status codes: `200` OK, `201` created, `400` invalid input, `404` not found, `405` wrong method, `413` request too large, `500` server error. Stack traces stay in the server log and are never sent to the browser.

## Settings and categories

Open **Settings** in the app to change, with no code and no restart:

- **Profile:** display name, tagline (the small text under your name) and the app name
- **Currency:** INR, USD, EUR, GBP or JPY. Every amount, chart and insight follows it.
- **Theme and sidebar:** saved with your data, not just in the browser
- **Categories:** add one (name, emoji, color), edit one, or delete one. Renaming a category moves all of its expenses along. Deleting a category that has expenses asks where to move them. You always keep at least one category (up to 24).

| Method | Endpoint | What it does |
|---|---|---|
| GET | `/api/config` | Settings, categories, current currency, supported currencies, storage info |
| PUT | `/api/settings` | Save any of `app_name`, `display_name`, `tagline`, `currency`, `theme`, `sidebar_collapsed` |
| GET | `/api/categories` | Categories with the number of expenses in each |
| POST | `/api/categories` | Add `{name, emoji, color}` → `201` |
| PUT | `/api/categories/<name>` | Edit or rename (expenses follow a rename) |
| DELETE | `/api/categories/<name>?reassign_to=<other>` | Delete; `reassign_to` is required when it has expenses |

## Example expense

```json
{
  "id": 1,
  "date": "2026-10-05",
  "category": "Food",
  "amount": 450,
  "description": "Lunch"
}
```

Add one with curl:

```bash
curl -X POST http://127.0.0.1:5000/api/expenses \
  -H "Content-Type: application/json" \
  -d '{"date":"2026-10-05","category":"Food","amount":450,"description":"Lunch"}'
```

Validation rules: the date is a real date in `YYYY-MM-DD` and not in the future; the category is one of your categories; the amount is a number above 0 with at most 2 decimals (up to 1 crore / 10,000,000); the description is 1–80 characters.

## Troubleshooting

- **"Can't reach the server" in the app:** the backend is not running. Start it with `python app.py` from the `backend` folder.
- **`ModuleNotFoundError`:** activate your virtual environment and run `pip install -r requirements.txt`.
- **Port 5000 already in use** (common on macOS, where AirPlay uses it): change `port=5000` at the bottom of `backend/app.py`. If you open `index.html` directly, also change the address in `ORIGIN` at the top of `frontend/js/app.js`.
- **Charts look old or missing:** delete the PNGs in `charts/`. They are regenerated automatically when your data changes.
- **"Using the JSON file" note, or Compass shows no data:** MongoDB is not running or the URI is wrong. Start MongoDB (see above), check `MONGODB_URI`, and restart the app.
- **"Unable to reach the database" while using the app:** MongoDB stopped after the app started. Start it again; no restart is needed.
- **Corrupted `expenses.json` (JSON mode):** the backend moves it aside as `expenses.corrupt-<time>.json` and starts empty. Invalid records inside an otherwise valid file are skipped and logged.
- **Fonts look different offline:** Plus Jakarta Sans loads from Google Fonts. Without internet the system font is used.
