'use strict';
/* Spendly frontend. All data comes from the Flask backend (backend/app.py):
   expenses are stored in JSON, analysis is done with Pandas, report charts are drawn by Matplotlib. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
// Everything below is loaded from the backend (GET /api/config) and can be changed in Settings.
const FALLBACK_CAT = { e: '🏷️', c: '#64748b' };
const CAT_MAP = {};
const CATS = new Proxy(CAT_MAP, { get: (t, k) => (k in t ? t[k] : FALLBACK_CAT) });
let CAT_NAMES = [];
let CUR = { code: 'INR', symbol: '₹', locale: 'en-IN' };
let CFG = { settings: { app_name: 'Spendly', display_name: 'Subham', tagline: 'Personal plan', currency: 'INR', theme: 'light', sidebar_collapsed: false }, categories: [], currencies: [], storage: null };

/* ---------- helpers ---------- */
const fmt = n => CUR.symbol + Math.round(n).toLocaleString(CUR.locale);
const fmt2 = n => CUR.symbol + n.toLocaleString(CUR.locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const money = n => Number.isInteger(n) ? fmt(n) : fmt2(n);
const short = v => CUR.symbol + (CUR.code === 'INR' && v >= 100000 ? +(v / 100000).toFixed(1) + 'L' : v >= 1000000 ? +(v / 1000000).toFixed(1) + 'M' : v >= 1000 ? +(v / 1000).toFixed(1) + 'k' : v);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const pd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const dshort = s => pd(s).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const ic = (n, c = '') => `<svg class="svg-i ${c}" aria-hidden="true"><use href="#i-${n}"/></svg>`;
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } }
};
const compact = () => matchMedia('(max-width:620px)').matches;
const badge = c => `<span class="badge" style="--c:${CATS[c].c}">${esc(c)}</span>`;

/* ---------- API client ---------- */
const ORIGIN = location.protocol === 'file:' ? 'http://127.0.0.1:5000' : '';
const API = ORIGIN + '/api';
async function call(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(API + path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  } catch (e) {
    throw { network: true, message: 'Cannot reach the server. Start the backend with "python app.py" and try again.' };
  }
  let data = null; try { data = await res.json(); } catch (e) { /* non-JSON body */ }
  if (!res.ok) throw { status: res.status, message: (data && data.error) || 'Something went wrong. Please try again.', fields: (data && data.fields) || {} };
  return data;
}
const api = {
  list: q => call('/expenses?' + q),
  get: id => call('/expenses/' + id).then(r => r.expense),
  add: b => call('/expenses', { method: 'POST', body: b }),
  update: (id, b) => call('/expenses/' + id, { method: 'PUT', body: b }),
  remove: id => call('/expenses/' + id, { method: 'DELETE' }),
  sample: () => call('/expenses/sample', { method: 'POST' }),
  clear: () => call('/expenses?confirm=true', { method: 'DELETE' }),
  summary: () => call('/analytics/summary').then(s => (setBell(s.insights), s)),
  categories: m => call('/analytics/categories' + (m ? '?month=' + m : '')),
  monthly: n => call('/analytics/monthly?months=' + n).then(r => r.months),
  report: (m, c) => call('/analytics/report?' + new URLSearchParams({ ...(m && { month: m }), ...(c && { compare: c }) })),
  charts: (t, size) => call(`/analytics/charts?theme=${t}&size=${size}`)
};
async function downloadFrom(path, name) {
  try {
    const res = await fetch(API + path);
    if (!res.ok) { let d = null; try { d = await res.json(); } catch (e) { /* ignore */ } throw { message: (d && d.error) || 'Export failed.' }; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(await res.blob()); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 500);
    return true;
  } catch (e) { toast(e instanceof TypeError || !e.message ? 'Unable to export. Is the backend running?' : e.message, 'error'); return false; }
}

/* ---------- client-side validation (the backend validates again) ---------- */
function validate(v) {
  const er = {}, c = {};
  const d = String(v.date || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || iso(pd(d)) !== d || d < '2000-01-01') er.Date = 'Please choose a valid date.';
  else if (d > iso(new Date())) er.Date = "The date can't be in the future.";
  else c.date = d;
  if (!CAT_NAMES.includes(v.category)) er.Cat = 'Please select a category.'; else c.category = v.category;
  const a = String(v.amount ?? '').trim();
  if (!/^\d+(\.\d{1,2})?$/.test(a)) er.Amt = 'Please enter a valid expense amount, using numbers only (for example 500 or 99.50).';
  else if (+a <= 0) er.Amt = 'The amount must be greater than 0.';
  else if (+a > 10000000) er.Amt = 'That amount is too large.';
  else c.amount = +a;
  const t = String(v.description || '').trim().replace(/\s+/g, ' ');
  if (!t) er.Desc = 'Please add a short description.';
  else if (t.length > 80) er.Desc = 'Keep the description under 80 characters.';
  else c.description = t;
  return { errors: er, clean: c };
}

/* ---------- SVG charts (interactive dashboard/analytics views) ---------- */
function scale(max, int) {
  const raw = Math.max(max, 1) / 4, mag = 10 ** Math.floor(Math.log10(raw));
  let step = [1, 2, 2.5, 5, 10].find(m => m * mag >= raw) * mag; if (int) step = Math.ceil(step);
  return { step, top: step * 4 };
}
function axes(W, H, L, R, T, B, sc, yf) {
  const ih = H - T - B; let g = '';
  for (let i = 0; i <= 4; i++) { const y = T + ih - i * ih / 4; g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/><text class="ax" x="${L - 8}" y="${y + 4}" text-anchor="end">${yf(sc.step * i)}</text>`; }
  return g;
}
function lineChart(id, labels, vals) {
  const sm = compact(), W = sm ? 360 : 640, H = sm ? 230 : 260, L = sm ? 46 : 54, R = 16, T = 14, B = 30, iw = W - L - R, ih = H - T - B, sc = scale(Math.max(...vals), false);
  const x = i => L + (vals.length === 1 ? iw / 2 : i * iw / (vals.length - 1)), y = v => T + ih - v / sc.top * ih;
  const p = vals.map((v, i) => [x(i), y(v)]);
  const d = p.map((q, i) => i ? `C${(p[i - 1][0] + q[0]) / 2},${p[i - 1][1]} ${(p[i - 1][0] + q[0]) / 2},${q[1]} ${q[0]},${q[1]}` : `M${q[0]},${q[1]}`).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Line chart of monthly spending">
  <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--primary-2);stop-opacity:.3"/><stop offset="1" style="stop-color:var(--primary-2);stop-opacity:0"/></linearGradient></defs>
  ${axes(W, H, L, R, T, B, sc, short)}<path class="fade" fill="url(#${id})" d="${d}L${p.at(-1)[0]},${T + ih}L${p[0][0]},${T + ih}Z"/>
  <path class="line draw" pathLength="1" d="${d}"/>
  ${p.map((q, i) => `<circle class="dot" cx="${q[0]}" cy="${q[1]}" r="4.5"><title>${esc(labels[i])}: ${fmt(vals[i])}</title></circle><text class="ax" x="${q[0]}" y="${H - 8}" text-anchor="middle">${esc(labels[i])}</text>`).join('')}</svg>`;
}
function bars(items, yf, h = 270) {
  const sm = compact(), W = sm ? 360 : 640, H = sm ? Math.min(h, 300) : h, L = sm ? 46 : 54, R = 10, T = 14, B = sm ? 34 : 46, iw = W - L - R, ih = H - T - B, sc = scale(Math.max(...items.map(i => i.v)), false);
  const slot = iw / items.length, bw = Math.min(slot * .62, 56);
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Bar chart of spending by category">${axes(W, H, L, R, T, B, sc, yf)}
  ${items.map((it, i) => { const bh = it.v / sc.top * ih, x = L + slot * i + (slot - bw) / 2;
    return `<rect class="bar" style="animation-delay:${i * 50}ms" x="${x}" y="${T + ih - bh}" width="${bw}" height="${bh}" rx="6" fill="${it.c}"><title>${esc(it.tip)}</title></rect>
    <text class="ax" x="${x + bw / 2}" y="${H - 26}" text-anchor="middle">${it.l1}</text><text class="ax" x="${x + bw / 2}" y="${H - 11}" text-anchor="middle">${esc(it.l2)}</text>`; }).join('')}</svg>`;
}
function donut(data, top, sub) {
  const tot = data.reduce((s, d) => s + d.val, 0); let off = 0;
  const segs = data.filter(d => d.val > 0).map(d => { const p = d.val / tot * 100, l = Math.max(p - .8, .1);
    const s = `<circle class="seg" cx="90" cy="90" r="64" stroke="${d.color}" stroke-dasharray="${l} ${100 - l}" stroke-dashoffset="${-off}" pathLength="100"><title>${esc(d.name)}: ${fmt(d.val)} (${p.toFixed(1)}%)</title></circle>`; off += p; return s; }).join('');
  return `<svg class="donut" viewBox="0 0 180 180" role="img" aria-label="Spending split by category"><circle class="donut-bg" cx="90" cy="90" r="64"/><g transform="rotate(-90 90 90)">${segs}</g>
  <text class="d-top" x="90" y="91" text-anchor="middle">${top}</text><text class="d-sub" x="90" y="106" text-anchor="middle">${sub}</text></svg>`;
}
const catData = cats => cats.map(c => ({ name: c.category, val: c.total, color: CATS[c.category].c }));
const legend = cats => `<div class="legend">${cats.filter(c => c.total > 0).map(c => `<div class="lg"><i style="background:${CATS[c.category].c}"></i><span>${CATS[c.category].e} ${esc(c.category)}</span><b>${fmt(c.total)}</b><em>${c.share}%</em></div>`).join('')}</div>`;
const catBars = cats => cats.map(c => ({ l1: CATS[c.category].e, l2: compact() ? '' : c.category.length > 8 ? c.category.slice(0, 7) + '…' : c.category, v: c.total, c: CATS[c.category].c, tip: `${esc(c.category)}: ${fmt(c.total)}` }));
const catRows = cats => cats.map(c => `<div class="bar-row" style="--c:${CATS[c.category].c}"><span>${CATS[c.category].e} ${esc(c.category)}</span><div class="track"><div class="fill" style="width:${c.share}%"></div></div><b>${fmt(c.total)}</b><em>${c.share}%</em></div>`).join('');

/* ---------- shared UI pieces ---------- */
const empty = (t = 'No expenses yet', p = 'Start tracking your spending by adding your first expense.') =>
  `<div class="card empty"><div class="big">📊</div><h3>${t}</h3><p>${p}</p><a class="btn primary" href="#add">${ic('plus')}Add expense</a></div>`;
const chip = (p, upBad = true) => p === null || p === undefined ? '' : `<span class="chip ${Math.abs(p) < .05 ? '' : (p > 0) === upBad ? 'bad' : 'good'}">${ic(p >= 0 ? 'up' : 'down')}${Math.abs(p).toFixed(1)}%</span>`;
const statCard = (cls, icon, label, val, sub, chipHtml = '', kind = 'money') =>
  `<article class="card stat ${cls}"><div class="stat-top"><span class="ico">${ic(icon)}</span>${chipHtml}</div><div class="stat-val" data-count="${val}" data-kind="${kind}">${kind === 'int' ? val : money(val)}</div><div class="stat-lbl">${label}</div><div class="stat-sub">${sub}</div></article>`;
const recRow = e => `<div class="rec" style="--c:${CATS[e.category].c}"><span class="emo">${CATS[e.category].e}</span><div><b>${esc(e.description)}</b><small>${esc(e.category)} · ${dshort(e.date)}</small></div><span class="amt">${money(e.amount)}</span></div>`;
const SKELETON = `<div class="grid g4">${'<div class="card skel" style="height:150px"></div>'.repeat(4)}</div><div class="grid g21"><div class="card skel" style="height:340px"></div><div class="card skel" style="height:340px"></div></div>`;
function countUp(root) {
  const calm = matchMedia('(prefers-reduced-motion:reduce)').matches;
  $$('[data-count]', root).forEach(el => {
    const to = +el.dataset.count, int = el.dataset.kind === 'int', f = v => int ? Math.round(v) : money(Math.round(v));
    if (calm || !to) return; const t0 = performance.now();
    (function step(t) { const k = Math.min((t - t0) / 900, 1); el.textContent = f(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); else el.textContent = int ? to : money(to); })(t0);
  });
}
function toast(msg, type = 'success') {
  const t = document.createElement('div'); t.className = 'toast ' + type; t.setAttribute('role', 'status');
  t.textContent = (type === 'success' ? '✓ ' : type === 'error' ? '✕ ' : '⚠ ') + msg; $('#toasts').append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3400);
}
function confirmBox({ title, html, ok }) {
  const dlg = $('#confirmDlg'); $('#cTitle').textContent = title; $('#cBody').innerHTML = html; $('#cYes').textContent = ok;
  return new Promise(res => { const done = v => { dlg.onclose = null; dlg.close(); res(v); };
    $('#cYes').onclick = () => done(true); $('#cNo').onclick = () => done(false); dlg.onclose = () => res(false); dlg.showModal(); });
}
function failure(e) {
  if (e && e.network === undefined && e.message === undefined) console.error(e);
  const net = e && e.network, html = `<div class="card empty"><div class="big">${net ? '🔌' : '⚠️'}</div><h3>${net ? "Can't reach the server" : 'Something went wrong'}</h3><p>${esc((e && e.message) || 'Please try again.')}</p><button class="btn primary" data-retry>Try again</button></div>`;
  (S.page === 'expenses' ? $('#expTable') : $('#p-' + S.page)).innerHTML = html;
}

/* ---------- forms ---------- */
const FK = { date: 'Date', category: 'Cat', amount: 'Amt', description: 'Desc' }, KEYS = ['Date', 'Cat', 'Amt', 'Desc'];
const fieldsHTML = p => `
<div class="field"><label for="${p}Date">Date</label><input type="date" id="${p}Date" max="${iso(new Date())}"><small class="err" id="${p}Date-err" role="alert"></small></div>
<div class="field"><label for="${p}Cat">Category</label><select id="${p}Cat"><option value="">Select a category</option>${CAT_NAMES.map(c => `<option value="${c}">${CATS[c].e} ${c}</option>`).join('')}</select><small class="err" id="${p}Cat-err" role="alert"></small></div>
<div class="field"><label for="${p}Amt">Amount</label><div class="money"><span class="cur-sym" aria-hidden="true">${CUR.symbol}</span><input id="${p}Amt" inputmode="decimal" autocomplete="off" placeholder="500"></div><small class="err" id="${p}Amt-err" role="alert"></small></div>
<div class="field wide"><label for="${p}Desc">Description</label><input id="${p}Desc" autocomplete="off" placeholder="Lunch with friends"><small class="err" id="${p}Desc-err" role="alert"></small></div>`;
const readForm = p => ({ date: $(`#${p}Date`).value, category: $(`#${p}Cat`).value, amount: $(`#${p}Amt`).value, description: $(`#${p}Desc`).value });
function showErrs(p, er) {
  KEYS.forEach(k => { $(`#${p}${k}-err`).textContent = er[k] || ''; $(`#${p}${k}`).setAttribute('aria-invalid', er[k] ? 'true' : 'false'); });
  const first = KEYS.find(k => er[k]); if (first) $(`#${p}${first}`).focus(); return first ? er[first] : null;
}
function clearErr(p, k) { $(`#${p}${k}-err`).textContent = ''; $(`#${p}${k}`).setAttribute('aria-invalid', 'false'); }
function watchErrors(form, p) {
  ['input', 'change'].forEach(ev => form.addEventListener(ev, e => { const k = KEYS.find(k => e.target.id === p + k); if (k) clearErr(p, k); }));
}
function serverErrs(p, e) { // map backend field errors onto the form
  const er = {}; for (const k in (e.fields || {})) if (FK[k]) er[FK[k]] = e.fields[k];
  return Object.keys(er).length ? showErrs(p, er) : null;
}
async function afterChange() { await render(); }

function initAdd() {
  $('#addFields').innerHTML = fieldsHTML('a'); $('#editFields').innerHTML = fieldsHTML('m');
  const reset = () => { $('#addForm').reset(); $('#aDate').value = iso(new Date()); showErrs('a', {}); $$('[data-quick]').forEach(b => b.setAttribute('aria-pressed', 'false')); };
  reset(); watchErrors($('#addForm'), 'a'); watchErrors($('#editForm'), 'm');
  $('#quickCats').addEventListener('click', e => { const b = e.target.closest('[data-quick]'); if (!b) return;
    $('#aCat').value = b.dataset.quick; clearErr('a', 'Cat'); $$('[data-quick]').forEach(x => x.setAttribute('aria-pressed', x === b)); });
  $('#aCat').addEventListener('change', () => $$('[data-quick]').forEach(x => x.setAttribute('aria-pressed', x.dataset.quick === $('#aCat').value)));
  $('#addReset').onclick = reset;
  $('#addForm').addEventListener('submit', async e => {
    e.preventDefault(); const r = validate(readForm('a')), msg = showErrs('a', r.errors);
    if (msg) return toast(msg, 'warn');
    const btn = $('#addBtn'); btn.disabled = true;
    try {
      await api.add(r.clean); reset(); const ok = $('#addOk'); ok.classList.remove('show'); void ok.offsetWidth; ok.classList.add('show');
      toast('Expense added successfully.'); render();
    } catch (err) { const m = serverErrs('a', err); toast(m || err.message || 'Unable to save expense.', m ? 'warn' : 'error'); }
    finally { btn.disabled = false; }
  });
  $('#editForm').addEventListener('submit', async e => {
    e.preventDefault(); const r = validate(readForm('m')), msg = showErrs('m', r.errors);
    if (msg) return toast(msg, 'warn');
    const btn = $('#editForm button[type=submit]'); btn.disabled = true;
    try { await api.update(editId, r.clean); $('#editDlg').close(); toast('Expense updated successfully.'); render(); }
    catch (err) { const m = serverErrs('m', err); toast(m || err.message || 'Unable to save expense.', m ? 'warn' : 'error'); }
    finally { btn.disabled = false; }
  });
}
let editId = null;
async function openEdit(id) {
  try {
    const e = await api.get(id); editId = id; showErrs('m', {});
    $('#mDate').value = e.date; $('#mCat').value = e.category; $('#mAmt').value = e.amount; $('#mDesc').value = e.description; $('#editDlg').showModal();
  } catch (err) { toast(err.message, 'error'); render(); }
}
async function askDelete(id) {
  let e; try { e = await api.get(id); } catch (err) { toast(err.message, 'error'); return render(); }
  const yes = await confirmBox({ title: 'Delete expense?', ok: 'Delete expense', html: `Are you sure you want to delete this expense?<div class="box"><b>${money(e.amount)}</b>${esc(e.category)} — ${esc(e.description)}</div>` });
  if (!yes) return;
  try { await api.remove(id); toast('Expense deleted successfully.'); } catch (err) { toast(err.message, 'error'); }
  render();
}

/* ---------- filters ---------- */
const S = { page: 'dashboard', q: '', range: 'all', from: '', to: '', cat: 'all', min: '', max: '', sort: 'date-desc', pg: 1, rm: '', rc: '' };
const PER = 10;
function filterQS() {
  const p = new URLSearchParams();
  if (S.q.trim()) p.set('q', S.q.trim());
  if (S.cat !== 'all') p.set('category', S.cat);
  if (S.range !== 'all') p.set('range', S.range);
  if (S.range === 'custom') { if (S.from) p.set('from', S.from); if (S.to) p.set('to', S.to); }
  if (S.min !== '') p.set('min', S.min);
  if (S.max !== '') p.set('max', S.max);
  p.set('sort', S.sort); return p.toString();
}
const refreshExp = () => R.expenses().catch(failure);
function initFilters() {
  const bind = (id, key, ev = 'input') => $(id).addEventListener(ev, e => { S[key] = e.target.value; S.pg = 1; if (key === 'range') $('#customBox').hidden = S.range !== 'custom'; refreshExp(); });
  bind('#fRange', 'range', 'change'); bind('#fCat', 'cat', 'change'); bind('#fSort', 'sort', 'change'); bind('#fFrom', 'from'); bind('#fTo', 'to'); bind('#fMin', 'min'); bind('#fMax', 'max');
  let tm; const setQ = v => { clearTimeout(tm); tm = setTimeout(() => { S.q = v; S.pg = 1; if (S.page !== 'expenses') location.hash = '#expenses'; else refreshExp(); }, 250); };
  $('#fSearch').addEventListener('input', e => { $('#gSearch').value = e.target.value; setQ(e.target.value); });
  $('#gSearch').addEventListener('input', e => { $('#fSearch').value = e.target.value; setQ(e.target.value); });
  $('#fClear').onclick = () => { Object.assign(S, { q: '', range: 'all', from: '', to: '', cat: 'all', min: '', max: '', sort: 'date-desc', pg: 1 }); syncFilters(); refreshExp(); };
  $('#fExport').onclick = async () => { if (await downloadFrom('/export?format=csv&' + filterQS(), 'expenses.csv')) toast('Exported the filtered expenses.'); };
}
function syncFilters() {
  $('#fSearch').value = $('#gSearch').value = S.q; $('#fRange').value = S.range; $('#fCat').value = S.cat; $('#fSort').value = S.sort;
  $('#fFrom').value = S.from; $('#fTo').value = S.to; $('#fMin').value = S.min; $('#fMax').value = S.max; $('#customBox').hidden = S.range !== 'custom';
}

/* ---------- pages ---------- */
const R = {};
R.dashboard = async () => {
  const el = $('#p-dashboard'); if (!el.firstChild) el.innerHTML = SKELETON;
  const [sm, cats, months, rec] = await Promise.all([api.summary(), api.categories(), api.monthly(6), api.list('sort=date-desc&per_page=6')]);
  if (S.page !== 'dashboard') return;
  if (!sm.count) { el.innerHTML = empty(); return; }
  const tm = sm.this_month, lm = sm.last_month_same_period;
  el.innerHTML = `
  <div class="grid g4 rise">
    ${statCard('hero', 'wallet', 'Total expenditure', sm.total, `${sm.count} transactions in total`, chip(sm.change_pct))}
    ${statCard('t-cyan', 'cal', 'This month', tm.total, `vs ${fmt(lm.total)} same days last month`, chip(sm.change_pct))}
    ${statCard('t-green', 'act', 'Average expense', sm.average, `This month: ${fmt(tm.average)}`, chip(sm.average_change_pct))}
    ${statCard('t-amber', 'up', 'Largest expense', sm.highest.amount, esc(sm.highest.description) + ' · ' + esc(sm.highest.category))}
  </div>
  <div class="grid g21">
    <section class="card"><div class="card-h"><div><h2 class="h2">Spending trend</h2><p class="sub">Monthly spending, last 6 months</p></div></div>
      ${lineChart('gTrend', months.map(m => m.label), months.map(m => m.total))}</section>
    <section class="card"><div class="card-h"><div><h2 class="h2">Category split</h2><p class="sub">All time</p></div></div>
      ${donut(catData(cats.categories), fmt(cats.total), 'total spent')}${legend(cats.categories)}</section>
  </div>
  <div class="grid g21">
    <section class="card"><div class="card-h"><div><h2 class="h2">Recent expenses</h2></div><a class="btn ghost sm" href="#expenses">View all</a></div><div class="recent">${rec.items.map(recRow).join('')}</div></section>
    <section class="card"><div class="card-h"><div><h2 class="h2">Spending insights</h2><p class="sub">Calculated from your data</p></div></div><div class="insights">${sm.insights.map(i => `<div class="ins ${i.tone || ''}"><span>${i.icon}</span><span>${esc(i.text)}</span></div>`).join('')}</div></section>
  </div>`;
  countUp(el);
};
R.add = async () => {
  const box = $('#addSide');
  try {
    const d = await api.list('sort=date-desc&per_page=5');
    box.innerHTML = `<h2 class="h2">Recently added</h2><p class="sub" style="margin-bottom:8px">Your latest entries</p><div class="recent">${d.items.map(recRow).join('') || '<p class="sub">Nothing yet.</p>'}</div>`;
  } catch (e) { box.innerHTML = `<h2 class="h2">Recently added</h2><p class="sub">${esc(e.message)}</p>`; }
};
let expTok = 0;
R.expenses = async () => {
  const tok = ++expTok, box = $('#expTable'); if (!box.firstChild) box.innerHTML = '<div class="card skel" style="height:320px"></div>';
  const d = await api.list(`${filterQS()}&page=${S.pg}&per_page=${PER}`);
  if (tok !== expTok) return;
  S.pg = d.page;
  if (!d.overall_count) { box.innerHTML = empty(); return; }
  if (!d.count) { box.innerHTML = `<div class="card empty"><div class="big">🔍</div><h3>No matching expenses</h3><p>Try a different search or reset the filters.</p><button class="btn ghost" id="emptyReset">Reset filters</button></div>`; $('#emptyReset').onclick = () => $('#fClear').click(); return; }
  box.innerHTML = `<div class="card"><div class="tbl-wrap"><table><thead><tr><th>Date</th><th>Category</th><th>Description</th><th class="amt">Amount</th><th class="acts">Actions</th></tr></thead><tbody>
  ${d.items.map(e => `<tr><td>${dshort(e.date)}</td><td>${badge(e.category)}</td><td class="desc" title="${esc(e.description)}">${esc(e.description)}</td><td class="amt">${money(e.amount)}</td>
  <td class="acts"><button class="icon-btn sm" data-edit="${e.id}" aria-label="Edit ${esc(e.description)}">${ic('edit', 'sm')}</button><button class="icon-btn sm del" data-del="${e.id}" aria-label="Delete ${esc(e.description)}">${ic('trash', 'sm')}</button></td></tr>`).join('')}
  </tbody></table></div>
  <div class="tbl-foot"><span>${d.count} expense${d.count > 1 ? 's' : ''} · total <b>${money(d.sum)}</b></span>
  <span class="pager"><button class="btn ghost sm" data-pg="-1" ${d.page <= 1 ? 'disabled' : ''}>Previous</button>Page ${d.page} of ${d.pages}<button class="btn ghost sm" data-pg="1" ${d.page >= d.pages ? 'disabled' : ''}>Next</button></span></div></div>`;
};
R.analytics = async () => {
  const el = $('#p-analytics'); if (!el.firstChild) el.innerHTML = SKELETON;
  const [sm, cats] = await Promise.all([api.summary(), api.categories()]);
  if (S.page !== 'analytics') return;
  if (!sm.count) { el.innerHTML = empty(); return; }
  const hl = (e, label) => `<section class="card"><p class="sub" style="margin-bottom:12px">${label}</p><div class="hl" style="--c:${CATS[e.category].c}"><span class="emo">${CATS[e.category].e}</span><div><div class="v">${money(e.amount)}</div>${badge(e.category)}<p class="sub" style="margin-top:6px">${esc(e.description)} · ${dshort(e.date)}</p></div></div></section>`;
  const tc = sm.top_category, fc = sm.frequent_category;
  el.innerHTML = `
  <div class="grid g4 rise">
    ${statCard('hero', 'wallet', 'Total spending', sm.total, 'All recorded expenses')}
    ${statCard('t-green', 'act', 'Average spending', sm.average, 'Per transaction')}
    ${statCard('t-amber', 'up', 'Highest expense', sm.highest.amount, esc(sm.highest.description))}
    ${statCard('t-cyan', 'down', 'Lowest expense', sm.lowest.amount, esc(sm.lowest.description))}
  </div>
  <div class="grid g3">
    <article class="card stat t-red"><div class="stat-top"><span class="ico">${ic('pie')}</span></div><div class="stat-val" style="font-size:24px">${CATS[tc.category].e} ${esc(tc.category)}</div><div class="stat-lbl">Most expensive category</div><div class="stat-sub">${fmt(tc.total)} in total</div></article>
    <article class="card stat"><div class="stat-top"><span class="ico">${ic('repeat')}</span></div><div class="stat-val" style="font-size:24px">${CATS[fc.category].e} ${esc(fc.category)}</div><div class="stat-lbl">Most frequent category</div><div class="stat-sub">${fc.count} transactions</div></article>
    ${statCard('t-green', 'hash', 'Number of transactions', sm.count, `Across ${sm.months_count} month${sm.months_count > 1 ? 's' : ''}`, '', 'int')}
  </div>
  <div class="grid g2">${hl(sm.highest, 'Highest expense')}${hl(sm.lowest, 'Lowest expense')}</div>
  <section class="card" style="margin-bottom:18px"><h2 class="h2" style="margin-bottom:16px">Average expenditure</h2>
    <div class="grid g4" style="margin:0"><div class="mini"><span class="v">${fmt2(sm.average)}</span><span class="k">Per expense</span></div>
    <div class="mini"><span class="v">${fmt2(sm.daily_average)}</span><span class="k">Daily average (${sm.days_span} days)</span></div>
    <div class="mini"><span class="v">${fmt2(sm.monthly_average)}</span><span class="k">Monthly average</span></div>
    <div class="mini"><span class="v" id="catAvgVal"></span><span class="k"><select class="inline" id="catAvgSel" aria-label="Category average">${CAT_NAMES.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('')}</select></span></div></div></section>
  <div class="grid g21"><section class="card"><h2 class="h2" style="margin-bottom:8px">Category totals</h2>${catRows(cats.categories)}</section>
    <section class="card"><h2 class="h2" style="margin-bottom:8px">By category</h2>${bars(catBars(cats.categories), short, 400)}</section></div>`;
  const upd = () => { const x = cats.categories.find(c => c.category === $('#catAvgSel').value); $('#catAvgVal').textContent = x.count ? fmt2(x.average) : '—'; };
  $('#catAvgSel').onchange = upd; upd(); countUp(el);
};
R.reports = async () => {
  const el = $('#p-reports'); if (!el.firstChild) el.innerHTML = '<div class="card skel" style="height:420px"></div>';
  const d = await api.report(S.rm, S.rc);
  if (S.page !== 'reports') return;
  if (!d.has_data) { el.innerHTML = empty(); return; }
  S.rm = d.month.key; S.rc = d.compare.key;
  const A = d.month, B = d.compare, mx = Math.max(A.total, B.total, 1), ch = d.change_pct;
  const opts = v => d.months.map(m => `<option value="${m.key}" ${m.key === v ? 'selected' : ''}>${m.label}</option>`).join('');
  const rows = A.categories.filter(c => c.total > 0);
  el.innerHTML = `
  <div class="card toolbar no-print"><div class="field row"><label class="sub" for="rMonth">Report month</label><select id="rMonth" class="inline">${opts(S.rm)}</select></div><div class="field row"><label class="sub" for="rCmp">Compare with</label><select id="rCmp" class="inline">${opts(S.rc)}</select></div>
    <span class="grow" style="flex:1"></span><button class="btn ghost" id="rPrint">${ic('print')}Print / save PDF</button><button class="btn ghost" id="rCsv">${ic('download')}Export month CSV</button></div>
  <div class="grid g21"><section class="card"><p class="sub">Monthly report</p><h2 style="font-size:26px;letter-spacing:-.02em;margin:2px 0 4px">${A.label}</h2>
    <div class="stat-val" style="margin:6px 0 14px">${fmt(A.total)} <span class="sub" style="font-weight:500;font-size:14px">across ${A.count} transactions</span></div>
    ${rows.length ? catRows(rows) : '<p class="sub">No expenses recorded in this month.</p>'}</section>
    <section class="card"><h2 class="h2" style="margin-bottom:6px">Category split</h2>${rows.length ? donut(catData(A.categories), fmt(A.total), A.label.split(' ')[0].slice(0, 3)) : '<p class="sub">Nothing to show.</p>'}</section></div>
  <section class="card" style="margin-bottom:18px"><div class="card-h"><div><h2 class="h2">Monthly comparison</h2><p class="sub">${B.label} vs ${A.label}</p></div>${chip(ch)}</div>
    <div class="cmp"><div class="cmp-row"><span>${B.label}</span><div class="track"><div class="fill" style="width:${B.total / mx * 100}%;--c:var(--info)"></div></div><b>${fmt(B.total)}</b></div>
    <div class="cmp-row"><span>${A.label}</span><div class="track"><div class="fill" style="width:${A.total / mx * 100}%;--c:var(--primary-2)"></div></div><b>${fmt(A.total)}</b></div></div>
    <p class="sub" style="margin-top:12px">${S.rm === S.rc ? 'Choose two different months to compare.' : ch === null ? 'The comparison month has no spending.' : `${d.difference >= 0 ? 'Increase' : 'Decrease'} of ${fmt(Math.abs(d.difference))} (${ch >= 0 ? '+' : ''}${ch.toFixed(1)}%).`}</p></section>
  <h2 class="h2 no-print" style="margin:6px 0 14px">Charts — all time</h2>
  <div class="grid g2" id="chartGrid">${'<div class="card skel" style="height:300px"></div>'.repeat(4)}</div>`;
  $('#rMonth').onchange = e => { S.rm = e.target.value; refreshPage(); }; $('#rCmp').onchange = e => { S.rc = e.target.value; refreshPage(); };
  $('#rPrint').onclick = () => window.print();
  $('#rCsv').onclick = async () => { const [y, m] = S.rm.split('-'), last = new Date(+y, +m, 0).getDate();
    if (await downloadFrom(`/export?format=csv&range=custom&from=${S.rm}-01&to=${S.rm}-${last}`, `report-${S.rm}.csv`)) toast('Report exported.'); };
  loadCharts();
};
async function loadCharts() {
  const box = $('#chartGrid'); if (!box) return;
  try {
    const d = await api.charts(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light', compact() ? 'compact' : 'wide');
    if ($('#chartGrid') !== box) return;
    box.innerHTML = d.charts.map(c => `<figure class="card chart-fig"><img src="${ORIGIN}${esc(c.url)}" alt="${esc(c.title)}" loading="lazy"></figure>`).join('');
  } catch (e) { box.innerHTML = `<div class="card empty" style="grid-column:1/-1"><h3>Charts unavailable</h3><p>${esc(e.message)}</p><button class="btn ghost" data-retry>Try again</button></div>`; }
}
R.categories = async () => {
  const el = $('#p-categories'); if (!el.firstChild) el.innerHTML = SKELETON;
  const d = await api.categories(); if (S.page !== 'categories') return;
  if (!d.total) { el.innerHTML = empty(); return; }
  el.innerHTML = `<div class="grid g4">${d.categories.map(c => `<article class="card cat-card" style="--c:${CATS[c.category].c}"><div class="stat-top"><span class="emo">${CATS[c.category].e}</span><span class="chip">${c.share}%</span></div>
  <h3 class="h2">${esc(c.category)}</h3><div class="stat-val" style="font-size:25px;margin:4px 0 12px">${fmt(c.total)}</div><div class="track"><div class="fill" style="width:${c.share}%"></div></div>
  <div class="row"><span>Transactions</span><b>${c.count}</b></div><div class="row"><span>Average</span><b>${c.count ? fmt(c.average) : '—'}</b></div>
  <button class="btn ghost sm" style="margin-top:14px;width:100%" data-viewcat="${esc(c.category)}">View expenses</button></article>`).join('')}</div>`;
};
function storageRow(st) {
  if (!st) return `<div class="set-row"><div><b>Storage</b><p>Storage status is unavailable. Is the backend running?</p></div></div>`;
  if (st.type === 'mongodb') return `<div class="set-row"><div><b>Storage: MongoDB</b><p>Database <code>${esc(st.database)}</code> · collection <code>${esc(st.collection)}</code>. Open it in MongoDB Compass with <code>${esc(st.uri)}</code>.</p></div><button class="btn ghost sm" data-copy="${esc(st.uri)}">Copy connection string</button></div>`;
  return `<div class="set-row"><div><b>Storage: JSON file</b><p>${esc(st.note || 'Expenses are saved in a local JSON file.')} <code>${esc(st.path)}</code></p></div></div>`;
}
const catRow = c => `<div class="cat-row"><span class="emo" style="--c:${c.color}">${esc(c.emoji)}</span><div><b>${esc(c.name)}</b><small>${c.count} expense${c.count === 1 ? '' : 's'}</small></div><span class="swatch" style="background:${c.color}" title="${c.color}"></span>
  <button class="icon-btn sm" data-catedit="${esc(c.name)}" aria-label="Edit ${esc(c.name)}">${ic('edit', 'sm')}</button><button class="icon-btn sm del" data-catdel="${esc(c.name)}" aria-label="Delete ${esc(c.name)}">${ic('trash', 'sm')}</button></div>`;
const reasonOf = err => (err && err.message) || 'Something went wrong. Please try again.';
R.settings = async () => {
  const [cfg, list] = await Promise.all([call('/config'), call('/categories')]);
  if (S.page !== 'settings') return;
  const st = cfg.settings, dark = st.theme === 'dark';
  $('#p-settings').innerHTML = `<div class="settings-col">
  <section class="card">${storageRow(cfg.storage)}
  <div class="set-row col"><div><b>Profile</b><p>Shown in the sidebar, the greeting and the page title.</p></div>
    <form id="profForm" class="prof-grid" novalidate>
      <div class="field"><label for="pName">Display name</label><input id="pName" maxlength="30" autocomplete="off" value="${esc(st.display_name)}"></div>
      <div class="field"><label for="pTag">Tagline</label><input id="pTag" maxlength="30" autocomplete="off" value="${esc(st.tagline)}"></div>
      <div class="field"><label for="pApp">App name</label><input id="pApp" maxlength="24" autocomplete="off" value="${esc(st.app_name)}"></div>
      <button class="btn primary">Save profile</button></form></div>
  <div class="set-row"><div><b>Currency</b><p>Used for every amount, chart and insight.</p></div><select id="curSel" class="inline" aria-label="Currency">${cfg.currencies.map(c => `<option value="${c.code}" ${c.code === st.currency ? 'selected' : ''}>${c.symbol} ${esc(c.name)} (${c.code})</option>`).join('')}</select></div>
  <div class="set-row"><div><b>Appearance</b><p>Light or dark theme. Saved to your account data.</p></div><div class="seg-ctl"><button data-theme="light" aria-pressed="${!dark}">☀ Light</button><button data-theme="dark" aria-pressed="${dark}">🌙 Dark</button></div></div>
  <div class="set-row"><div><b>Export data</b><p>Download all your expenses.</p></div><div style="display:flex;gap:8px"><button class="btn ghost" id="sCsv">${ic('download')}CSV</button><button class="btn ghost" id="sJson">${ic('download')}JSON</button></div></div>
  <div class="set-row"><div><b>Load sample data</b><p>Replace everything with realistic demo expenses.</p></div><button class="btn ghost" id="sReset">Load sample data</button></div>
  <div class="set-row"><div><b>Delete all expenses</b><p>Permanently removes every expense.</p></div><button class="btn danger" id="sClear">Delete all</button></div></section>
  <section class="card"><div class="card-h"><div><h2 class="h2">Categories</h2><p class="sub">Add, rename, recolor or remove categories. Renaming moves its expenses along.</p></div><button class="btn primary sm" id="catAdd">${ic('plus', 'sm')}Add category</button></div>
    <div class="cat-list">${list.categories.map(catRow).join('')}</div></section></div>`;
  $('#profForm').onsubmit = async e => { e.preventDefault();
    try { await saveSettings({ display_name: $('#pName').value, tagline: $('#pTag').value, app_name: $('#pApp').value }); toast('Profile saved.'); }
    catch (err) { toast(reasonOf(err), err.fields && Object.keys(err.fields).length ? 'warn' : 'error'); } };
  $('#curSel').onchange = async e => { try { await saveSettings({ currency: e.target.value }); toast(`Currency changed to ${CUR.code}.`); } catch (err) { toast(reasonOf(err), 'error'); R.settings(); } };
  $$('.seg-ctl [data-theme]').forEach(b => b.onclick = () => { setTheme(b.dataset.theme); saveSettings({ theme: b.dataset.theme }).catch(() => {}); $$('.seg-ctl [data-theme]').forEach(x => x.setAttribute('aria-pressed', x === b)); });
  $('#sCsv').onclick = async () => { if (await downloadFrom('/export?format=csv', 'spendly-expenses.csv')) toast('Exported as CSV.'); };
  $('#sJson').onclick = async () => { if (await downloadFrom('/export?format=json', 'expenses.json')) toast('Exported as JSON.'); };
  $('#sReset').onclick = async () => { if (!await confirmBox({ title: 'Load sample data?', ok: 'Replace data', html: 'This replaces all current expenses with sample data.' })) return;
    try { await api.sample(); toast('Sample data loaded.'); R.settings(); } catch (e) { toast(reasonOf(e), 'error'); } };
  $('#sClear').onclick = async () => { if (!await confirmBox({ title: 'Delete all expenses?', ok: 'Delete everything', html: 'This permanently removes every expense and cannot be undone.' })) return;
    try { await api.clear(); toast('All expenses deleted.'); R.settings(); } catch (e) { toast(reasonOf(e), 'error'); } };
  $('#catAdd').onclick = () => openCat();
  $$('[data-catedit]').forEach(b => b.onclick = () => openCat(b.dataset.catedit));
  $$('[data-catdel]').forEach(b => b.onclick = () => deleteCat(b.dataset.catdel));
};
let catEdit = null;
function openCat(name) {
  const c = name ? CFG.categories.find(x => x.name === name) : null; catEdit = c ? c.name : null;
  $('#catTitle').textContent = c ? 'Edit category' : 'Add category';
  $('#cName').value = c ? c.name : ''; $('#cEmoji').value = c ? c.emoji : ''; $('#cColor').value = c ? c.color : '#6366f1';
  ['Name', 'Emoji', 'Color'].forEach(k => { $(`#c${k}-err`).textContent = ''; $(`#c${k}`).setAttribute('aria-invalid', 'false'); });
  $('#catDlg').showModal(); $('#cName').focus();
}
async function saveCat(e) {
  e.preventDefault(); const btn = $('#catForm button[type=submit]'); btn.disabled = true;
  try {
    await call('/categories' + (catEdit ? '/' + encodeURIComponent(catEdit) : ''), { method: catEdit ? 'PUT' : 'POST', body: { name: $('#cName').value, emoji: $('#cEmoji').value, color: $('#cColor').value } });
    await loadConfig(); $('#catDlg').close(); toast(catEdit ? 'Category updated.' : 'Category added.'); if (S.page === 'settings') R.settings();
  } catch (err) {
    const f = err.fields || {}, keys = { name: 'Name', emoji: 'Emoji', color: 'Color' }; let shown = false;
    for (const k in keys) { const el = $(`#c${keys[k]}-err`); el.textContent = f[k] || ''; $(`#c${keys[k]}`).setAttribute('aria-invalid', f[k] ? 'true' : 'false'); shown = shown || !!f[k]; }
    toast(reasonOf(err), shown ? 'warn' : 'error');
  } finally { btn.disabled = false; }
}
async function deleteCat(name) {
  try {
    const list = (await call('/categories')).categories, c = list.find(x => x.name === name); if (!c) return R.settings();
    const others = list.filter(x => x.name !== name);
    if (!others.length) return toast('You need at least one category.', 'warn');
    const html = c.count
      ? `<p>${c.count} expense${c.count === 1 ? ' uses' : 's use'} <b>${esc(name)}</b>. Move ${c.count === 1 ? 'it' : 'them'} to:</p><div class="box"><select id="reassignSel" aria-label="Move expenses to">${others.map(o => `<option value="${esc(o.name)}">${esc(o.emoji)} ${esc(o.name)}</option>`).join('')}</select></div>`
      : `No expenses use <b>${esc(name)}</b>, so it will simply be removed.`;
    if (!await confirmBox({ title: 'Delete category?', ok: 'Delete category', html })) return;
    const target = c.count ? $('#reassignSel').value : '';
    const r = await call(`/categories/${encodeURIComponent(name)}` + (target ? `?reassign_to=${encodeURIComponent(target)}` : ''), { method: 'DELETE' });
    await loadConfig(); toast(r.moved ? `Category deleted. ${r.moved} expense${r.moved === 1 ? '' : 's'} moved to ${target}.` : 'Category deleted.'); R.settings();
  } catch (err) { toast(reasonOf(err), 'error'); }
}

/* ---------- shell: routing, theme, sidebar, notifications ---------- */
const userName = () => CFG.settings.display_name;
function applyCategories(cats) {
  Object.keys(CAT_MAP).forEach(k => delete CAT_MAP[k]);
  cats.forEach(c => { CAT_MAP[c.name] = { e: c.emoji, c: c.color }; });
  CAT_NAMES = cats.map(c => c.name);
}
function refreshCategoryUI() {
  const opts = CAT_NAMES.map(c => `<option value="${esc(c)}">${esc(CATS[c].e)} ${esc(c)}</option>`).join('');
  ['#aCat', '#mCat'].forEach(id => { const el = $(id); if (!el) return; const v = el.value; el.innerHTML = '<option value="">Select a category</option>' + opts; el.value = CAT_NAMES.includes(v) ? v : ''; });
  if (!CAT_NAMES.includes(S.cat)) S.cat = 'all';
  const f = $('#fCat'); if (f) { f.innerHTML = '<option value="all">All categories</option>' + opts; f.value = S.cat; }
  const q = $('#quickCats'), cur = $('#aCat') ? $('#aCat').value : '';
  if (q) q.innerHTML = CAT_NAMES.map(c => `<button type="button" class="chp" style="--c:${CATS[c].c}" data-quick="${esc(c)}" aria-pressed="${cur === c}">${esc(CATS[c].e)} ${esc(c)}</button>`).join('');
}
function applyConfig(cfg) {
  CFG = cfg; CUR = cfg.currency; applyCategories(cfg.categories);
  const st = cfg.settings;
  $$('[data-name]').forEach(e => e.textContent = st.display_name);
  $$('[data-initial]').forEach(e => e.textContent = st.display_name.trim().charAt(0).toUpperCase() || 'S');
  $$('[data-tagline]').forEach(e => e.textContent = st.tagline);
  $$('[data-app]').forEach(e => e.textContent = st.app_name);
  $$('.cur-sym').forEach(e => e.textContent = CUR.symbol);
  $('#fMin').placeholder = 'Min ' + CUR.symbol; $('#fMax').placeholder = 'Max ' + CUR.symbol;
  setTheme(st.theme);
  document.body.classList.toggle('collapsed', !!st.sidebar_collapsed); store.set('et.collapsed', st.sidebar_collapsed ? '1' : '0');
  $('#collapseBtn').setAttribute('aria-expanded', !st.sidebar_collapsed);
  refreshCategoryUI(); setTitle();
}
async function loadConfig() { applyConfig(await call('/config')); }
async function saveSettings(patch) { const r = await call('/settings', { method: 'PUT', body: patch }); applyConfig(r); return r; }
function setTheme(t) { document.documentElement.dataset.theme = t; store.set('et.theme', t); $('#themeBtn').innerHTML = ic(t === 'dark' ? 'sun' : 'moon'); $('#themeBtn').setAttribute('aria-label', t === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'); }
const TITLES = { add: ['Add expense', 'Record a new expense in a few seconds.'], expenses: ['Expenses', 'Search, filter, edit and manage every expense.'], analytics: ['Analytics', 'Detailed analysis of your spending.'],
  reports: ['Reports', 'Monthly reports, comparisons and charts.'], categories: ['Categories', 'See where your money goes.'], settings: ['Settings', 'Preferences and data.'] };
function setTitle() {
  if (S.page === 'dashboard') { const h = new Date().getHours(); $('#pageTitle').textContent = `Good ${h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : 'Evening'}, ${userName()} 👋`; $('#pageSub').textContent = "Here's your spending overview."; }
  else { $('#pageTitle').textContent = TITLES[S.page][0]; $('#pageSub').textContent = TITLES[S.page][1]; }
  document.title = `${S.page === 'dashboard' ? 'Dashboard' : TITLES[S.page][0]} — ${CFG.settings.app_name}`;
}
function setBell(ins) {
  $('#bellDot').hidden = !ins.some(i => i.tone);
  $('#notif').innerHTML = `<h3>Notifications</h3>${ins.map(i => `<p><span>${i.icon}</span><span>${esc(i.text)}</span></p>`).join('')}`;
}
async function render() {
  const page = S.page;
  try { await R[page](); if (page !== 'dashboard' && page !== 'analytics') api.summary().catch(() => {}); }
  catch (e) { if (page === S.page) failure(e); }
}
const refreshPage = render;
function route() {
  const h = (location.hash || '#dashboard').slice(1); S.page = R[h] ? h : 'dashboard';
  $$('.page').forEach(s => s.hidden = s.id !== 'p-' + S.page);
  $$('[data-page]').forEach(a => a.setAttribute('aria-current', a.dataset.page === S.page ? 'page' : 'false'));
  if (S.page === 'expenses') syncFilters();
  setTitle(); render(); document.body.classList.remove('nav-open'); scrollTo(0, 0);
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast('Connection string copied.'); }
  catch (e) { toast('Could not copy. Select the text and copy it manually.', 'warn'); }
}
async function init() {
  $('#todayLbl').textContent = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  setTheme(document.documentElement.dataset.theme || 'light'); initAdd(); initFilters(); $('#catForm').addEventListener('submit', saveCat);
  if (store.get('et.collapsed', '0') === '1') document.body.classList.add('collapsed');
  $('#collapseBtn').onclick = () => { const c = document.body.classList.toggle('collapsed'); store.set('et.collapsed', c ? '1' : '0'); saveSettings({ sidebar_collapsed: c }).catch(() => {}); $('#collapseBtn').setAttribute('aria-expanded', !c); };
  $('#menuBtn').onclick = $('#moreBtn').onclick = () => document.body.classList.add('nav-open'); $('#scrim').onclick = () => document.body.classList.remove('nav-open');
  $('#themeBtn').onclick = () => { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; setTheme(t); saveSettings({ theme: t }).catch(() => {}); if (S.page === 'reports') loadCharts(); if (S.page === 'settings') $$('.seg-ctl [data-theme]').forEach(x => x.setAttribute('aria-pressed', x.dataset.theme === t)); };
  $('#bellBtn').onclick = e => { e.stopPropagation(); const n = $('#notif'); n.hidden = !n.hidden; $('#bellBtn').setAttribute('aria-expanded', !n.hidden); };
  document.addEventListener('click', e => { if (!e.target.closest('.pop-wrap')) { $('#notif').hidden = true; $('#bellBtn').setAttribute('aria-expanded', 'false'); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { $('#notif').hidden = true; document.body.classList.remove('nav-open'); } });
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-edit],[data-del],[data-pg],[data-viewcat],[data-close],[data-retry],[data-copy]'); if (!t) return;
    if (t.dataset.copy) return copyText(t.dataset.copy);
    if (t.dataset.edit) openEdit(+t.dataset.edit); else if (t.dataset.del) askDelete(+t.dataset.del);
    else if (t.dataset.pg) { S.pg += +t.dataset.pg; refreshExp(); }
    else if (t.dataset.viewcat) { Object.assign(S, { cat: t.dataset.viewcat, range: 'all', q: '', min: '', max: '', pg: 1 }); location.hash = '#expenses'; }
    else if (t.hasAttribute('data-retry')) loadConfig().catch(() => {}).then(render);
    else if (t.hasAttribute('data-close')) t.closest('dialog').close();
  });
  $$('dialog').forEach(d => d.addEventListener('click', e => { if (e.target === d && d.id === 'editDlg') d.close(); }));
  // redraw charts when crossing the phone breakpoint (rotate / resize)
  matchMedia('(max-width:620px)').addEventListener('change', () => { if (['dashboard', 'analytics', 'reports'].includes(S.page)) render(); });
  window.addEventListener('hashchange', route);
  try { await loadConfig(); } catch (e) { /* backend down: every page shows a retry card */ }
  route();
}
init();
